(function(){var P$=Clazz.newPackage("java.beans"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "PropertyChangeListener", null, null, 'java.util.EventListener');

C$.$clinit$=2;
})();
;Clazz.setTVer('5.0.1-v6');//Created 2025-03-10 13:43:47 Java2ScriptVisitor version 5.0.1-v6 net.sf.j2s.core.jar version 5.0.1-v6
