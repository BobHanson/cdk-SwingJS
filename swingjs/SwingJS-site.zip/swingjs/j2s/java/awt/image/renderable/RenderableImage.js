(function(){var P$=Clazz.newPackage("java.awt.image.renderable"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "RenderableImage");
})();
;Clazz.setTVer('5.0.1-v6');//Created 2025-03-10 13:43:46 Java2ScriptVisitor version 5.0.1-v6 net.sf.j2s.core.jar version 5.0.1-v6
