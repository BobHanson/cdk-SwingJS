(function(){var P$=Clazz.newPackage("_ES6"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "InChIWeb");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'importWASM$',  function () {
try {
{
var j2sPath = J2S._applets.master._j2sFullPath;
J2S.inchiPath = J2S._applets.master._j2sFullPath + "/_ES6";
$.getScript(J2S.inchiPath +   "/inchi-web-SwingJS.js");
}
} catch (t) {
}
}, 1);

Clazz.newMeth(C$, 'initAndRun$Runnable',  function (r) {

if (!J2S) { alert("J2S has not been installed");
System.exit(0);
} var t = [];
t[0] = setInterval( function(){ if (J2S.inchiWasmLoaded && J2S.inchiWasmLoaded()) { clearInterval(t[0]);
System.out.println("InChI WASM initialized successfully");
r.run$();
} }, 50);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v5');//Created 2025-02-27 19:37:49 Java2ScriptVisitor version 5.0.1-v5 net.sf.j2s.core.jar version 5.0.1-v5
