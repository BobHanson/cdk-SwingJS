(function(){var P$=Clazz.newPackage("_ES6"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "InChIWeb");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v5');//Created 2025-02-24 22:11:34 Java2ScriptVisitor version 5.0.1-v5 net.sf.j2s.core.jar version 5.0.1-v5
