(function(){var P$=Clazz.newPackage("io.github.dan2097.jnainchi"),I$=[[0,'java.util.HashMap']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*e*/var C$=Clazz.newClass(P$, "InchiBondStereo", null, 'Enum');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['B',['code']]
,['O',['map','java.util.Map']]]

Clazz.newMeth(C$, 'c$$I',  function (code) {
;C$.$init$.apply(this);
this.code=($b$[0] = code, $b$[0]);
}, 1);

Clazz.newMeth(C$, 'getCode$',  function () {
return this.code;
});

Clazz.newMeth(C$, 'getCodeObj$O',  function (val) {
if (val != null ) {
var e=(Clazz.instanceOf(val, "io.github.dan2097.jnainchi.InchiBondStereo") ? val : C$.map.get$O(val.toString().toLowerCase$()));
if (e != null ) return e.getCode$();
}return C$.NONE.getCode$();
}, 1);

Clazz.newMeth(C$, 'of$B',  function (code) {
return C$.map.get$O(Byte.valueOf$B(code));
}, 1);

C$.$static$=function(){C$.$static$=0;
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$$I, "NONE", 0, [0]);
Clazz.newEnumConst($vals, C$.c$$I, "SINGLE_1UP", 1, [1]);
Clazz.newEnumConst($vals, C$.c$$I, "SINGLE_1EITHER", 2, [4]);
Clazz.newEnumConst($vals, C$.c$$I, "SINGLE_1DOWN", 3, [6]);
Clazz.newEnumConst($vals, C$.c$$I, "SINGLE_2UP", 4, [-1]);
Clazz.newEnumConst($vals, C$.c$$I, "SINGLE_2EITHER", 5, [-4]);
Clazz.newEnumConst($vals, C$.c$$I, "SINGLE_2DOWN", 6, [-6]);
Clazz.newEnumConst($vals, C$.c$$I, "DOUBLE_EITHER", 7, [3]);
C$.map=Clazz.new_($I$(1,1));
{
for (var val, $val = 0, $$val = C$.values$(); $val<$$val.length&&((val=($$val[$val])),1);$val++) {
C$.map.put$O$O(Byte.valueOf$B(val.code), val);
C$.map.put$O$O(val.name$().toLowerCase$(), val);
}
};
};
var $b$ = new Int8Array(1);

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values$', function() { return $vals }, 1);
Clazz.newMeth(C$, 'valueOf$S', function(name) { for (var val in $vals){ if ($vals[val].name == name) return $vals[val]} return null }, 1);
})();
;Clazz.setTVer('5.0.1-v6');//Created 2025-03-21 12:04:23 Java2ScriptVisitor version 5.0.1-v6 net.sf.j2s.core.jar version 5.0.1-v6
