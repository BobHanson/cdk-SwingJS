(function(){var P$=Clazz.newPackage("io.github.dan2097.jnainchi.inchi"),I$=[[0,'java.util.Arrays']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "tagInchiAtom", null, 'com.sun.jna.Structure', [['com.sun.jna.Structure','com.sun.jna.Structure.ByReference']]);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.neighbor=Clazz.array(Short.TYPE, [20]);
this.bond_type=Clazz.array(Byte.TYPE, [20]);
this.bond_stereo=Clazz.array(Byte.TYPE, [20]);
this.elname=Clazz.array(Byte.TYPE, [6]);
this.num_iso_H=Clazz.array(Byte.TYPE, [4]);
},1);

C$.$fields$=[['B',['radical','charge'],'D',['x','y','z'],'H',['num_bonds','isotopic_mass'],'O',['neighbor','short[]','bond_type','byte[]','+bond_stereo','+elname','+num_iso_H']]]

Clazz.newMeth(C$, 'getFieldOrder$',  function () {
return $I$(1,"asList$OA",[Clazz.array(String, -1, ["x", "y", "z", "neighbor", "bond_type", "bond_stereo", "elname", "num_bonds", "num_iso_H", "isotopic_mass", "radical", "charge"])]);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v5');//Created 2025-02-24 22:11:33 Java2ScriptVisitor version 5.0.1-v5 net.sf.j2s.core.jar version 5.0.1-v5
