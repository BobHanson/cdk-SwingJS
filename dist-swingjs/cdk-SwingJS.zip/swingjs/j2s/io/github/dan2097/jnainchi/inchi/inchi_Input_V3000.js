(function(){var P$=Clazz.newPackage("io.github.dan2097.jnainchi.inchi"),I$=[[0,'java.util.Arrays']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "inchi_Input_V3000", null, 'com.sun.jna.Structure', [['com.sun.jna.Structure','com.sun.jna.Structure.ByReference']]);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['n_non_star_atoms','n_star_atoms','n_sgroups','n_3d_constraints','n_collections','n_non_haptic_bonds','n_haptic_bonds','n_steabs','n_sterel','n_sterac'],'O',['atom_index_orig','com.sun.jna.ptr.IntByReference','+atom_index_fin','lists_haptic_bonds','com.sun.jna.ptr.PointerByReference','+lists_steabs','+lists_sterel','+lists_sterac']]]

Clazz.newMeth(C$, 'getFieldOrder$',  function () {
return $I$(1,"asList$OA",[Clazz.array(String, -1, ["n_non_star_atoms", "n_star_atoms", "atom_index_orig", "atom_index_fin", "n_sgroups", "n_3d_constraints", "n_collections", "n_non_haptic_bonds", "n_haptic_bonds", "lists_haptic_bonds", "n_steabs", "lists_steabs", "n_sterel", "lists_sterel", "n_sterac", "lists_sterac"])]);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v6');//Created 2025-03-11 17:50:54 Java2ScriptVisitor version 5.0.1-v6 net.sf.j2s.core.jar version 5.0.1-v6
