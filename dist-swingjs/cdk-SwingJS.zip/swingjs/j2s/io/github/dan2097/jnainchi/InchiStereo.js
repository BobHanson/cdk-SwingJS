(function(){var P$=Clazz.newPackage("io.github.dan2097.jnainchi"),I$=[[0,'io.github.dan2097.jnainchi.InchiAtom','io.github.dan2097.jnainchi.InchiStereoType']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "InchiStereo");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['atoms','io.github.dan2097.jnainchi.InchiAtom[]','centralAtom','io.github.dan2097.jnainchi.InchiAtom','type','io.github.dan2097.jnainchi.InchiStereoType','parity','io.github.dan2097.jnainchi.InchiStereoParity']]
,['O',['STEREO_IMPLICIT_H','io.github.dan2097.jnainchi.InchiAtom']]]

Clazz.newMeth(C$, 'c$$io_github_dan2097_jnainchi_InchiAtomA$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiStereoType$io_github_dan2097_jnainchi_InchiStereoParity',  function (atoms, centralAtom, type, parity) {
;C$.$init$.apply(this);
if (atoms == null ) {
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["atoms was null"]);
}if (type == null ) {
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["type was null"]);
}if (parity == null ) {
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["parity was null"]);
}if (atoms.length != 4) {
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["Atoms array should be length 4"]);
}for (var i=0; i < atoms.length; i++) {
if (atoms[i] == null ) {
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["Atom at index " + i + " was null, use STEREO_IMPLICIT_H for implicit hydrogen, and the atom with a lone pair for lone pairs" ]);
}}
if (type !== $I$(2).DoubleBond  && centralAtom == null  ) {
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["centralAtom was null"]);
}this.atoms=atoms;
this.centralAtom=centralAtom;
this.type=type;
this.parity=parity;
}, 1);

Clazz.newMeth(C$, 'createTetrahedralStereo$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiStereoParity',  function (centralAtom, atom1, atom2, atom3, atom4, parity) {
return Clazz.new_(C$.c$$io_github_dan2097_jnainchi_InchiAtomA$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiStereoType$io_github_dan2097_jnainchi_InchiStereoParity,[Clazz.array($I$(1), -1, [atom1, atom2, atom3, atom4]), centralAtom, $I$(2).Tetrahedral, parity]);
}, 1);

Clazz.newMeth(C$, 'createDoubleBondStereo$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiStereoParity',  function (atom1, atom2, atom3, atom4, parity) {
if (C$.STEREO_IMPLICIT_H === atom1  || C$.STEREO_IMPLICIT_H === atom2   || C$.STEREO_IMPLICIT_H === atom3   || C$.STEREO_IMPLICIT_H === atom4  ) {
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["Double bond stereo should use non-implicit hydrogn atoms"]);
}return Clazz.new_(C$.c$$io_github_dan2097_jnainchi_InchiAtomA$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiStereoType$io_github_dan2097_jnainchi_InchiStereoParity,[Clazz.array($I$(1), -1, [atom1, atom2, atom3, atom4]), null, $I$(2).DoubleBond, parity]);
}, 1);

Clazz.newMeth(C$, 'createAllenalStereo$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiStereoParity',  function (centralAtom, atom1, atom2, atom3, atom4, parity) {
return Clazz.new_(C$.c$$io_github_dan2097_jnainchi_InchiAtomA$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiStereoType$io_github_dan2097_jnainchi_InchiStereoParity,[Clazz.array($I$(1), -1, [atom1, atom2, atom3, atom4]), centralAtom, $I$(2).Allene, parity]);
}, 1);

Clazz.newMeth(C$, 'getAtoms$',  function () {
return this.atoms;
});

Clazz.newMeth(C$, 'getCentralAtom$',  function () {
return this.centralAtom;
});

Clazz.newMeth(C$, 'getType$',  function () {
return this.type;
});

Clazz.newMeth(C$, 'getParity$',  function () {
return this.parity;
});

C$.$static$=function(){C$.$static$=0;
C$.STEREO_IMPLICIT_H=Clazz.new_($I$(1,1).c$$S,["H"]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-02 04:53:14 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
