(function(){var P$=Clazz.newPackage("io.github.dan2097.jnainchi"),I$=[[0,'java.util.HashMap']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*e*/var C$=Clazz.newClass(P$, "InchiKeyStatus", null, 'Enum');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['code']]
,['O',['map','java.util.Map']]]

Clazz.newMeth(C$, 'c$$I',  function (code) {
;C$.$init$.apply(this);
this.code=code;
}, 1);

Clazz.newMeth(C$, 'of$I',  function (code) {
return C$.map.get$O(Integer.valueOf$I(code));
}, 1);

C$.$static$=function(){C$.$static$=0;
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$$I, "OK", 0, [0]);
Clazz.newEnumConst($vals, C$.c$$I, "UNKNOWN_ERROR", 1, [1]);
Clazz.newEnumConst($vals, C$.c$$I, "EMPTY_INPUT", 2, [2]);
Clazz.newEnumConst($vals, C$.c$$I, "INVALID_INCHI_PREFIX", 3, [3]);
Clazz.newEnumConst($vals, C$.c$$I, "NOT_ENOUGH_MEMORY", 4, [4]);
Clazz.newEnumConst($vals, C$.c$$I, "INVALID_INCHI", 5, [20]);
Clazz.newEnumConst($vals, C$.c$$I, "INVALID_STD_INCHI", 6, [21]);
C$.map=Clazz.new_($I$(1,1));
{
for (var val, $val = 0, $$val = C$.values$(); $val<$$val.length&&((val=($$val[$val])),1);$val++) {
C$.map.put$O$O(Integer.valueOf$I(val.code), val);
}
};
};

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values$', function() { return $vals }, 1);
Clazz.newMeth(C$, 'valueOf$S', function(name) { for (var val in $vals){ if ($vals[val].name == name) return $vals[val]} return null }, 1);
})();
;Clazz.setTVer('5.0.1-v6');//Created 2025-03-10 15:41:30 Java2ScriptVisitor version 5.0.1-v6 net.sf.j2s.core.jar version 5.0.1-v6
