(function(){var P$=Clazz.newPackage("io.github.dan2097.jnainchi.inchi"),I$=[[0,'java.util.Arrays']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "tagINCHIStereo0D", null, 'com.sun.jna.Structure', [['com.sun.jna.Structure','com.sun.jna.Structure.ByReference']]);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.neighbor=Clazz.array(Short.TYPE, [4]);
},1);

C$.$fields$=[['B',['type','parity'],'H',['central_atom'],'O',['neighbor','short[]']]]

Clazz.newMeth(C$, 'getFieldOrder$',  function () {
return $I$(1,"asList$OA",[Clazz.array(String, -1, ["neighbor", "central_atom", "type", "parity"])]);
});

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$HA$H$B$B',  function (neighbor, central_atom, type, parity) {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
if ((neighbor.length != this.neighbor.length)) throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["Wrong array size !"]);
this.neighbor=neighbor;
this.central_atom=central_atom;
this.type=type;
this.parity=parity;
}, 1);
})();
;Clazz.setTVer('5.0.1-v5');//Created 2025-03-03 18:33:49 Java2ScriptVisitor version 5.0.1-v5 net.sf.j2s.core.jar version 5.0.1-v5
