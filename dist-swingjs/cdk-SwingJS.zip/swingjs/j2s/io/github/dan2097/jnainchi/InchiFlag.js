(function(){var P$=Clazz.newPackage("io.github.dan2097.jnainchi"),I$=[];
/*e*/var C$=Clazz.newClass(P$, "InchiFlag", null, 'Enum');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'toString',  function () {
if (this === C$.OneFiveT ) {
return "15T";
}return C$.superclazz.prototype.toString.apply(this, []);
});

Clazz.newMeth(C$, 'getFlagFromName$S',  function (name) {
for (var item, $item = 0, $$item = C$.values$(); $item<$$item.length&&((item=($$item[$item])),1);$item++) if (item.toString().equalsIgnoreCase$S(name)) return item;

return null;
}, 1);

C$.$static$=function(){C$.$static$=0;
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$, "NEWPSOFF", 0, []);
Clazz.newEnumConst($vals, C$.c$, "DoNotAddH", 1, []);
Clazz.newEnumConst($vals, C$.c$, "SNon", 2, []);
Clazz.newEnumConst($vals, C$.c$, "SRel", 3, []);
Clazz.newEnumConst($vals, C$.c$, "SRac", 4, []);
Clazz.newEnumConst($vals, C$.c$, "SUCF", 5, []);
Clazz.newEnumConst($vals, C$.c$, "ChiralFlagON", 6, []);
Clazz.newEnumConst($vals, C$.c$, "ChiralFlagOFF", 7, []);
Clazz.newEnumConst($vals, C$.c$, "LargeMolecules", 8, []);
Clazz.newEnumConst($vals, C$.c$, "SUU", 9, []);
Clazz.newEnumConst($vals, C$.c$, "SLUUD", 10, []);
Clazz.newEnumConst($vals, C$.c$, "FixedH", 11, []);
Clazz.newEnumConst($vals, C$.c$, "RecMet", 12, []);
Clazz.newEnumConst($vals, C$.c$, "KET", 13, []);
Clazz.newEnumConst($vals, C$.c$, "OneFiveT", 14, []);
Clazz.newEnumConst($vals, C$.c$, "AuxNone", 15, []);
Clazz.newEnumConst($vals, C$.c$, "WarnOnEmptyStructure", 16, []);
Clazz.newEnumConst($vals, C$.c$, "SaveOpt", 17, []);
Clazz.newEnumConst($vals, C$.c$, "NoWarnings", 18, []);
Clazz.newEnumConst($vals, C$.c$, "LooseTSACheck", 19, []);
Clazz.newEnumConst($vals, C$.c$, "Polymers", 20, []);
Clazz.newEnumConst($vals, C$.c$, "Polymers105", 21, []);
Clazz.newEnumConst($vals, C$.c$, "FoldCRU", 22, []);
Clazz.newEnumConst($vals, C$.c$, "NoFrameShift", 23, []);
Clazz.newEnumConst($vals, C$.c$, "NoEdits", 24, []);
Clazz.newEnumConst($vals, C$.c$, "NPZz", 25, []);
Clazz.newEnumConst($vals, C$.c$, "SAtZz", 26, []);
Clazz.newEnumConst($vals, C$.c$, "SAbs", 27, []);
Clazz.newEnumConst($vals, C$.c$, "OutErrInChI", 28, []);
};

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values$', function() { return $vals }, 1);
Clazz.newMeth(C$, 'valueOf$S', function(name) { for (var val in $vals){ if ($vals[val].name == name) return $vals[val]} return null }, 1);
})();
;Clazz.setTVer('5.0.1-v6');//Created 2025-03-10 15:41:30 Java2ScriptVisitor version 5.0.1-v6 net.sf.j2s.core.jar version 5.0.1-v6
