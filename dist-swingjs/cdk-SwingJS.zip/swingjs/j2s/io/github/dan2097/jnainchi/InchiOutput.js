(function(){var P$=Clazz.newPackage("io.github.dan2097.jnainchi"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "InchiOutput");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['inchi','auxInfo','message','log'],'O',['status','io.github.dan2097.jnainchi.InchiStatus']]]

Clazz.newMeth(C$, 'c$$S$S$S$S$io_github_dan2097_jnainchi_InchiStatus',  function (inchi, auxInfo, message, log, status) {
;C$.$init$.apply(this);
this.inchi=inchi;
this.auxInfo=auxInfo;
this.message=message;
this.log=log;
this.status=status;
}, 1);

Clazz.newMeth(C$, 'getInchi$',  function () {
return this.inchi;
});

Clazz.newMeth(C$, 'getAuxInfo$',  function () {
return this.auxInfo;
});

Clazz.newMeth(C$, 'getMessage$',  function () {
return this.message;
});

Clazz.newMeth(C$, 'getLog$',  function () {
return this.log;
});

Clazz.newMeth(C$, 'getStatus$',  function () {
return this.status;
});

Clazz.newMeth(C$, 'toString',  function () {
return this.inchi;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v6');//Created 2025-03-21 12:04:23 Java2ScriptVisitor version 5.0.1-v6 net.sf.j2s.core.jar version 5.0.1-v6
