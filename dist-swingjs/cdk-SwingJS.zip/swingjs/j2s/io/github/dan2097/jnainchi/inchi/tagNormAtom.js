(function(){var P$=Clazz.newPackage("io.github.dan2097.jnainchi.inchi"),I$=[[0,'java.util.Arrays']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "tagNormAtom", null, 'com.sun.jna.Structure', [['com.sun.jna.Structure','com.sun.jna.Structure.ByReference']]);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.elname=Clazz.array(Byte.TYPE, [6]);
this.neighbor=Clazz.array(Short.TYPE, [20]);
this.bond_stereo=Clazz.array(Byte.TYPE, [20]);
this.bond_type=Clazz.array(Byte.TYPE, [20]);
this.num_iso_H=Clazz.array(Byte.TYPE, [3]);
this.p_orig_at_num=Clazz.array(Short.TYPE, [4]);
this.sb_ord=Clazz.array(Byte.TYPE, [3]);
this.sn_ord=Clazz.array(Byte.TYPE, [3]);
this.sb_parity=Clazz.array(Byte.TYPE, [3]);
this.sn_orig_at_num=Clazz.array(Short.TYPE, [3]);
},1);

C$.$fields$=[['B',['el_number','valence','chem_bonds_valence','num_H','iso_atw_diff','charge','radical','bAmbiguousStereo','cFlags','bUsed0DParity','p_parity','bCutVertex'],'D',['x','y','z'],'H',['orig_at_number','orig_compt_at_numb','at_type','component','endpoint','c_point','nRingSystem','nNumAtInRingSystem','nBlockSystem'],'O',['elname','byte[]','neighbor','short[]','bond_stereo','byte[]','+bond_type','+num_iso_H','p_orig_at_num','short[]','sb_ord','byte[]','+sn_ord','+sb_parity','sn_orig_at_num','short[]']]]

Clazz.newMeth(C$, 'getFieldOrder$',  function () {
return $I$(1,"asList$OA",[Clazz.array(String, -1, ["elname", "el_number", "neighbor", "orig_at_number", "orig_compt_at_numb", "bond_stereo", "bond_type", "valence", "chem_bonds_valence", "num_H", "num_iso_H", "iso_atw_diff", "charge", "radical", "bAmbiguousStereo", "cFlags", "at_type", "component", "endpoint", "c_point", "x", "y", "z", "bUsed0DParity", "p_parity", "p_orig_at_num", "sb_ord", "sn_ord", "sb_parity", "sn_orig_at_num", "bCutVertex", "nRingSystem", "nNumAtInRingSystem", "nBlockSystem"])]);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v5');//Created 2025-02-24 22:11:33 Java2ScriptVisitor version 5.0.1-v5 net.sf.j2s.core.jar version 5.0.1-v5
