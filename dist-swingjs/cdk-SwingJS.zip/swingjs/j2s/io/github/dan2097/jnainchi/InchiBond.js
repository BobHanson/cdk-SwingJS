(function(){var P$=Clazz.newPackage("io.github.dan2097.jnainchi"),I$=[[0,'io.github.dan2097.jnainchi.InchiBondStereo']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "InchiBond");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['start','io.github.dan2097.jnainchi.InchiAtom','+end','type','io.github.dan2097.jnainchi.InchiBondType','stereo','io.github.dan2097.jnainchi.InchiBondStereo']]]

Clazz.newMeth(C$, 'c$$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiBondType',  function (start, end, type) {
C$.c$$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiBondType$io_github_dan2097_jnainchi_InchiBondStereo.apply(this, [start, end, type, $I$(1).NONE]);
}, 1);

Clazz.newMeth(C$, 'c$$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiBondType$io_github_dan2097_jnainchi_InchiBondStereo',  function (start, end, type, stereo) {
;C$.$init$.apply(this);
if (start.equals$O(end)) {
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["start and end must be different atoms"]);
}if (type == null ) {
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["type must not be null"]);
}if (stereo == null ) {
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["stereo must not be null, use InchiBondStereo.NONE"]);
}this.start=start;
this.end=end;
this.type=type;
this.stereo=stereo;
}, 1);

Clazz.newMeth(C$, 'getStart$',  function () {
return this.start;
});

Clazz.newMeth(C$, 'getEnd$',  function () {
return this.end;
});

Clazz.newMeth(C$, 'getType$',  function () {
return this.type;
});

Clazz.newMeth(C$, 'getStereo$',  function () {
return this.stereo;
});

Clazz.newMeth(C$, 'getOther$io_github_dan2097_jnainchi_InchiAtom',  function (atom) {
if (this.start === atom ) {
return this.end;
}if (this.end === atom ) {
return this.start;
}return null;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v6');//Created 2025-03-21 12:04:23 Java2ScriptVisitor version 5.0.1-v6 net.sf.j2s.core.jar version 5.0.1-v6
