(function(){var P$=Clazz.newPackage("io.github.dan2097.jnainchi"),I$=[[0,'java.util.HashMap','com.sun.jna.Platform','io.github.dan2097.jnainchi.inchi.InchiLibrary','io.github.dan2097.jnainchi.InchiOptions','io.github.dan2097.jnainchi.inchi.IxaFunctions','io.github.dan2097.jnainchi.InchiRadical','io.github.dan2097.jnainchi.InchiBondType','io.github.dan2097.jnainchi.InchiBondStereo','io.github.dan2097.jnainchi.InchiStereoType','io.github.dan2097.jnainchi.InchiStereo','io.github.dan2097.jnainchi.InchiFlag','io.github.dan2097.jnainchi.InchiStatus','StringBuilder','io.github.dan2097.jnainchi.InchiOutput','io.github.dan2097.jnainchi.inchi.tagINCHI_Output','io.github.dan2097.jnainchi.InchiKeyStatus','java.nio.charset.StandardCharsets','io.github.dan2097.jnainchi.InchiKeyOutput','io.github.dan2097.jnainchi.InchiCheckStatus','io.github.dan2097.jnainchi.InchiKeyCheckStatus','io.github.dan2097.jnainchi.inchi.tagINCHI_Input','io.github.dan2097.jnainchi.inchi.tagInchiInpData','io.github.dan2097.jnainchi.InchiInput','io.github.dan2097.jnainchi.inchi.tagInchiAtom','io.github.dan2097.jnainchi.inchi.tagINCHIStereo0D','io.github.dan2097.jnainchi.InchiInputFromAuxinfoOutput','io.github.dan2097.jnainchi.inchi.tagINCHI_InputINCHI','io.github.dan2097.jnainchi.inchi.tagINCHI_OutputStruct','io.github.dan2097.jnainchi.InchiInputFromInchiOutput','io.github.dan2097.jnainchi.InchiAtom','io.github.dan2097.jnainchi.InchiBond','io.github.dan2097.jnainchi.InchiStereoParity','java.util.Properties']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JnaInchi");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['S',['platform'],'O',['libraryLoadingError','Throwable','inchiBaseAtomicMasses','java.util.Map']]]

Clazz.newMeth(C$, 'toInchi$io_github_dan2097_jnainchi_InchiInput',  function (inchiInput) {
return C$.toInchi$io_github_dan2097_jnainchi_InchiInput$io_github_dan2097_jnainchi_InchiOptions(inchiInput, $I$(4).DEFAULT_OPTIONS);
}, 1);

Clazz.newMeth(C$, 'toInchi$io_github_dan2097_jnainchi_InchiInput$io_github_dan2097_jnainchi_InchiOptions',  function (inchiInput, options) {
C$.checkLibrary$();
var atoms=inchiInput.getAtoms$();
var atomCount=atoms.size$();
if (atomCount > 32767) {
throw Clazz.new_(Clazz.load('IllegalStateException').c$$S,["InChI is limited to 32767 atoms, input contained " + atomCount + " atoms" ]);
}var bonds=inchiInput.getBonds$();
var stereos=inchiInput.getStereos$();
if (stereos.size$() > 32767) {
throw Clazz.new_(Clazz.load('IllegalStateException').c$$S,["Too many stereochemistry elements in input"]);
}var logger=$I$(5).IXA_STATUS_Create$();
var nativeMol=$I$(5).IXA_MOL_Create$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE(logger);
$I$(5,"IXA_MOL_ReserveSpace$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$I$I$I",[logger, nativeMol, atomCount, bonds.size$(), stereos.size$()]);
try {
var atomToNativeAtom=C$.addAtoms$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$java_util_List(nativeMol, logger, atoms);
C$.addBonds$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$java_util_List$java_util_Map(nativeMol, logger, bonds, atomToNativeAtom);
C$.addStereos$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$java_util_List$java_util_Map(nativeMol, logger, stereos, atomToNativeAtom);
return C$.buildInchi$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_InchiOptions(logger, nativeMol, options);
} finally {
$I$(5).IXA_MOL_Destroy$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE(logger, nativeMol);
$I$(5).IXA_STATUS_Destroy$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE(logger);
}
}, 1);

Clazz.newMeth(C$, 'addAtoms$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$java_util_List',  function (mol, logger, atoms) {
var atomToNativeAtom=Clazz.new_($I$(1,1));
for (var atom, $atom = atoms.iterator$(); $atom.hasNext$()&&((atom=($atom.next$())),1);) {
var nativeAtom=$I$(5).IXA_MOL_CreateAtom$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE(logger, mol);
atomToNativeAtom.put$O$O(atom, nativeAtom);
if (atom.getX$() != 0 ) {
$I$(5,"IXA_MOL_SetAtomX$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$D",[logger, mol, nativeAtom, atom.getX$()]);
}if (atom.getY$() != 0 ) {
$I$(5,"IXA_MOL_SetAtomY$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$D",[logger, mol, nativeAtom, atom.getY$()]);
}if (atom.getZ$() != 0 ) {
$I$(5,"IXA_MOL_SetAtomZ$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$D",[logger, mol, nativeAtom, atom.getZ$()]);
}var elName=atom.getElName$();
if (!elName.equals$O("C")) {
if (elName.length$() > 5) {
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["Element name was too long: " + elName]);
}$I$(5).IXA_MOL_SetAtomElement$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$S(logger, mol, nativeAtom, elName);
}if (atom.getIsotopicMass$() != 0) {
$I$(5,"IXA_MOL_SetAtomMass$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$I",[logger, mol, nativeAtom, atom.getIsotopicMass$()]);
}if (atom.getCharge$() != 0) {
$I$(5,"IXA_MOL_SetAtomCharge$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$I",[logger, mol, nativeAtom, atom.getCharge$()]);
}if (atom.getRadical$() !== $I$(6).NONE ) {
$I$(5,"IXA_MOL_SetAtomRadical$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$I",[logger, mol, nativeAtom, atom.getRadical$().getCode$()]);
}if (atom.getImplicitHydrogen$() != 0) {
$I$(5,"IXA_MOL_SetAtomHydrogens$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$I$I",[logger, mol, nativeAtom, 0, atom.getImplicitHydrogen$()]);
}if (atom.getImplicitProtium$() != 0) {
$I$(5,"IXA_MOL_SetAtomHydrogens$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$I$I",[logger, mol, nativeAtom, 1, atom.getImplicitProtium$()]);
}if (atom.getImplicitDeuterium$() != 0) {
$I$(5,"IXA_MOL_SetAtomHydrogens$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$I$I",[logger, mol, nativeAtom, 2, atom.getImplicitDeuterium$()]);
}if (atom.getImplicitTritium$() != 0) {
$I$(5,"IXA_MOL_SetAtomHydrogens$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$I$I",[logger, mol, nativeAtom, 3, atom.getImplicitTritium$()]);
}}
return atomToNativeAtom;
}, 1);

Clazz.newMeth(C$, 'addBonds$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$java_util_List$java_util_Map',  function (mol, logger, bonds, atomToNativeAtom) {
for (var bond, $bond = bonds.iterator$(); $bond.hasNext$()&&((bond=($bond.next$())),1);) {
var nativeAtom1=atomToNativeAtom.get$O(bond.getStart$());
var nativeAtom2=atomToNativeAtom.get$O(bond.getEnd$());
if (nativeAtom1 == null  || nativeAtom2 == null  ) {
throw Clazz.new_(Clazz.load('IllegalStateException').c$$S,["Bond referenced an atom that was not part of the InchiInput"]);
}var nativeBond=$I$(5).IXA_MOL_CreateBond$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID(logger, mol, nativeAtom1, nativeAtom2);
var bondType=bond.getType$();
if (bondType !== $I$(7).SINGLE ) {
$I$(5,"IXA_MOL_SetBondType$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_BONDID$I",[logger, mol, nativeBond, bondType.getCode$()]);
}switch (bond.getStereo$()) {
case $I$(8).DOUBLE_EITHER:
$I$(5).IXA_MOL_SetDblBondConfig$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_BONDID$I(logger, mol, nativeBond, 1);
break;
case $I$(8).SINGLE_1DOWN:
$I$(5).IXA_MOL_SetBondWedge$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_BONDID$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$I(logger, mol, nativeBond, nativeAtom1, 2);
break;
case $I$(8).SINGLE_1EITHER:
$I$(5).IXA_MOL_SetBondWedge$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_BONDID$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$I(logger, mol, nativeBond, nativeAtom1, 3);
break;
case $I$(8).SINGLE_1UP:
$I$(5).IXA_MOL_SetBondWedge$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_BONDID$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$I(logger, mol, nativeBond, nativeAtom1, 1);
break;
case $I$(8).SINGLE_2DOWN:
$I$(5).IXA_MOL_SetBondWedge$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_BONDID$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$I(logger, mol, nativeBond, nativeAtom2, 2);
break;
case $I$(8).SINGLE_2EITHER:
$I$(5).IXA_MOL_SetBondWedge$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_BONDID$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$I(logger, mol, nativeBond, nativeAtom2, 3);
break;
case $I$(8).SINGLE_2UP:
$I$(5).IXA_MOL_SetBondWedge$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_BONDID$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$I(logger, mol, nativeBond, nativeAtom2, 1);
break;
case $I$(8).NONE:
break;
}
}
}, 1);

Clazz.newMeth(C$, 'addStereos$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$java_util_List$java_util_Map',  function (nativeMol, logger, stereos, atomToNativeAtom) {
for (var stereo, $stereo = stereos.iterator$(); $stereo.hasNext$()&&((stereo=($stereo.next$())),1);) {
var type=stereo.getType$();
if (type === $I$(9).None ) {
continue;
}var atomsInCenter=stereo.getAtoms$();
var vertex1=C$.getStereoVertex$java_util_Map$io_github_dan2097_jnainchi_InchiAtom(atomToNativeAtom, atomsInCenter[0]);
var vertex2=C$.getStereoVertex$java_util_Map$io_github_dan2097_jnainchi_InchiAtom(atomToNativeAtom, atomsInCenter[1]);
var vertex3=C$.getStereoVertex$java_util_Map$io_github_dan2097_jnainchi_InchiAtom(atomToNativeAtom, atomsInCenter[2]);
var vertex4=C$.getStereoVertex$java_util_Map$io_github_dan2097_jnainchi_InchiAtom(atomToNativeAtom, atomsInCenter[3]);
var center;
switch (type) {
case $I$(9).Tetrahedral:
{
var centralAtom=atomToNativeAtom.get$O(stereo.getCentralAtom$());
if (centralAtom == null ) {
throw Clazz.new_(Clazz.load('IllegalStateException').c$$S,["Stereo configuration central atom referenced an atom that does not exist"]);
}center=$I$(5).IXA_MOL_CreateStereoTetrahedron$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID(logger, nativeMol, centralAtom, vertex1, vertex2, vertex3, vertex4);
break;
}case $I$(9).Allene:
{
var centralAtom=atomToNativeAtom.get$O(stereo.getCentralAtom$());
if (centralAtom == null ) {
throw Clazz.new_(Clazz.load('IllegalStateException').c$$S,["Stereo configuration central atom referenced an atom that does not exist"]);
}center=$I$(5).IXA_MOL_CreateStereoAntiRectangle$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID(logger, nativeMol, centralAtom, vertex1, vertex2, vertex3, vertex4);
break;
}case $I$(9).DoubleBond:
{
var centralBond=$I$(5).IXA_MOL_GetCommonBond$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID(logger, nativeMol, vertex2, vertex3);
if (centralBond == null ) {
throw Clazz.new_(Clazz.load('IllegalStateException').c$$S,["Could not find olefin/cumulene central bond"]);
}center=$I$(5,"IXA_MOL_CreateStereoRectangle$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_BONDID$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_ATOMID",[logger, nativeMol, centralBond, vertex1, $I$(5).IXA_ATOMID_IMPLICIT_H, $I$(5).IXA_ATOMID_IMPLICIT_H, vertex4]);
break;
}default:
throw Clazz.new_(Clazz.load('IllegalStateException').c$$S,["Unexpected InChI stereo type:" + type]);
}
var parity=stereo.getParity$().getCode$();
$I$(5).IXA_MOL_SetStereoParity$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STEREOID$I(logger, nativeMol, center, parity);
}
}, 1);

Clazz.newMeth(C$, 'getStereoVertex$java_util_Map$io_github_dan2097_jnainchi_InchiAtom',  function (atomToNativeAtom, inchiAtom) {
if ($I$(10).STEREO_IMPLICIT_H === inchiAtom ) {
return $I$(5).IXA_ATOMID_IMPLICIT_H;
}var vertex=atomToNativeAtom.get$O(inchiAtom);
if (vertex == null ) {
throw Clazz.new_(Clazz.load('IllegalStateException').c$$S,["Stereo configuration referenced an atom that does not exist"]);
}return vertex;
}, 1);

Clazz.newMeth(C$, 'buildInchi$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_InchiOptions',  function (logger, nativeMol, options) {
var builder=$I$(5).IXA_INCHIBUILDER_Create$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE(logger);
try {
$I$(5).IXA_INCHIBUILDER_SetMolecule$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE(logger, builder, nativeMol);
var timeoutMilliSecs=options.getTimeoutMilliSeconds$();
if (Long.$ne(timeoutMilliSecs,0 )) {
$I$(5).IXA_INCHIBUILDER_SetOption_Timeout_MilliSeconds$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE$J(logger, builder, timeoutMilliSecs);
}for (var flag, $flag = options.getFlags$().iterator$(); $flag.hasNext$()&&((flag=($flag.next$())),1);) {
switch (flag) {
case $I$(11).AuxNone:
$I$(5).IXA_INCHIBUILDER_SetOption$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE$I$Z(logger, builder, 9, true);
break;
case $I$(11).ChiralFlagOFF:
$I$(5).IXA_MOL_SetChiral$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$Z(logger, nativeMol, false);
break;
case $I$(11).ChiralFlagON:
$I$(5).IXA_MOL_SetChiral$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$Z(logger, nativeMol, true);
break;
case $I$(11).DoNotAddH:
$I$(5).IXA_INCHIBUILDER_SetOption$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE$I$Z(logger, builder, 1, true);
break;
case $I$(11).FixedH:
$I$(5).IXA_INCHIBUILDER_SetOption$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE$I$Z(logger, builder, 4, true);
break;
case $I$(11).KET:
$I$(5).IXA_INCHIBUILDER_SetOption$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE$I$Z(logger, builder, 6, true);
break;
case $I$(11).LargeMolecules:
$I$(5).IXA_INCHIBUILDER_SetOption$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE$I$Z(logger, builder, 11, true);
break;
case $I$(11).NEWPSOFF:
$I$(5).IXA_INCHIBUILDER_SetOption$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE$I$Z(logger, builder, 0, true);
break;
case $I$(11).OneFiveT:
$I$(5).IXA_INCHIBUILDER_SetOption$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE$I$Z(logger, builder, 7, true);
break;
case $I$(11).RecMet:
$I$(5).IXA_INCHIBUILDER_SetOption$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE$I$Z(logger, builder, 5, true);
break;
case $I$(11).SLUUD:
$I$(5).IXA_INCHIBUILDER_SetOption$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE$I$Z(logger, builder, 3, true);
break;
case $I$(11).SNon:
$I$(5).IXA_INCHIBUILDER_SetOption_Stereo$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE$I(logger, builder, 1);
break;
case $I$(11).SRac:
$I$(5).IXA_INCHIBUILDER_SetOption_Stereo$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE$I(logger, builder, 3);
break;
case $I$(11).SRel:
$I$(5).IXA_INCHIBUILDER_SetOption_Stereo$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE$I(logger, builder, 2);
break;
case $I$(11).SUCF:
$I$(5).IXA_INCHIBUILDER_SetOption_Stereo$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE$I(logger, builder, 4);
break;
case $I$(11).SAbs:
$I$(5).IXA_INCHIBUILDER_SetOption_Stereo$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE$I(logger, builder, 0);
break;
case $I$(11).SUU:
$I$(5).IXA_INCHIBUILDER_SetOption$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE$I$Z(logger, builder, 2, true);
break;
case $I$(11).SaveOpt:
$I$(5).IXA_INCHIBUILDER_SetOption$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE$I$Z(logger, builder, 8, true);
break;
case $I$(11).WarnOnEmptyStructure:
$I$(5).IXA_INCHIBUILDER_SetOption$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE$I$Z(logger, builder, 10, true);
break;
case $I$(11).NoWarnings:
$I$(5).IXA_INCHIBUILDER_SetOption$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE$I$Z(logger, builder, 24, true);
break;
case $I$(11).LooseTSACheck:
$I$(5).IXA_INCHIBUILDER_SetOption$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE$I$Z(logger, builder, 22, true);
break;
case $I$(11).Polymers:
$I$(5).IXA_INCHIBUILDER_SetOption$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE$I$Z(logger, builder, 12, true);
break;
case $I$(11).Polymers105:
$I$(5).IXA_INCHIBUILDER_SetOption$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE$I$Z(logger, builder, 13, true);
break;
case $I$(11).FoldCRU:
$I$(5).IXA_INCHIBUILDER_SetOption$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE$I$Z(logger, builder, 20, true);
break;
case $I$(11).NoFrameShift:
$I$(5).IXA_INCHIBUILDER_SetOption$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE$I$Z(logger, builder, 19, true);
break;
case $I$(11).NoEdits:
$I$(5).IXA_INCHIBUILDER_SetOption$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE$I$Z(logger, builder, 21, true);
break;
case $I$(11).NPZz:
$I$(5).IXA_INCHIBUILDER_SetOption$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE$I$Z(logger, builder, 17, true);
break;
case $I$(11).SAtZz:
$I$(5).IXA_INCHIBUILDER_SetOption$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE$I$Z(logger, builder, 18, true);
break;
case $I$(11).OutErrInChI:
$I$(5).IXA_INCHIBUILDER_SetOption$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE$I$Z(logger, builder, 23, true);
break;
default:
throw Clazz.new_(Clazz.load('IllegalStateException').c$$S,["Unexpected InChI option flag: " + flag]);
}
}
var inchi=$I$(5).IXA_INCHIBUILDER_GetInChI$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE(logger, builder);
var auxInfo=$I$(5).IXA_INCHIBUILDER_GetAuxInfo$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE(logger, builder);
var log=$I$(5).IXA_INCHIBUILDER_GetLog$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE(logger, builder);
var status=$I$(12).SUCCESS;
if ($I$(5).IXA_STATUS_HasError$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE(logger)) {
status=$I$(12).ERROR;
} else if ($I$(5).IXA_STATUS_HasWarning$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE(logger)) {
status=$I$(12).WARNING;
}var sb=Clazz.new_($I$(13,1));
var messageCount=$I$(5).IXA_STATUS_GetCount$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE(logger);
for (var i=0; i < messageCount; i++) {
if (i > 0) {
sb.append$S("; ");
}sb.append$S($I$(5).IXA_STATUS_GetMessage$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$I(logger, i));
}
return Clazz.new_([inchi, auxInfo, sb.toString(), log, status],$I$(14,1).c$$S$S$S$S$io_github_dan2097_jnainchi_InchiStatus);
} finally {
$I$(5).IXA_INCHIBUILDER_Destroy$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_INCHIBUILDER_HANDLE(logger, builder);
}
}, 1);

Clazz.newMeth(C$, 'molToInchi$S',  function (molText) {
return C$.molToInchi$S$io_github_dan2097_jnainchi_InchiOptions(molText, $I$(4).DEFAULT_OPTIONS);
}, 1);

Clazz.newMeth(C$, 'molToInchi$S$io_github_dan2097_jnainchi_InchiOptions',  function (molText, options) {
C$.checkLibrary$();
var nativeOutput=Clazz.new_($I$(15,1));
try {
var ret=$I$(3,"MakeINCHIFromMolfileText$S$S$io_github_dan2097_jnainchi_inchi_tagINCHI_Output",[molText, options.toString(), nativeOutput]);
var status;
switch (ret) {
case 0:
status=$I$(12).SUCCESS;
break;
case 1:
status=$I$(12).WARNING;
break;
case -1:
case 2:
case 4:
case 5:
status=$I$(12).ERROR;
break;
default:
status=$I$(12).ERROR;
break;
}
return Clazz.new_($I$(14,1).c$$S$S$S$S$io_github_dan2097_jnainchi_InchiStatus,[nativeOutput.szInChI, nativeOutput.szAuxInfo, nativeOutput.szMessage, nativeOutput.szLog, status]);
} finally {
$I$(3).FreeINCHI$io_github_dan2097_jnainchi_inchi_tagINCHI_Output(nativeOutput);
}
}, 1);

Clazz.newMeth(C$, 'inchiToInchi$S$io_github_dan2097_jnainchi_InchiOptions',  function (inchi, options) {
C$.checkLibrary$();
var logger=$I$(5).IXA_STATUS_Create$();
var nativeMol=$I$(5).IXA_MOL_Create$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE(logger);
try {
$I$(5).IXA_MOL_ReadInChI$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$S(logger, nativeMol, inchi);
return C$.buildInchi$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE$io_github_dan2097_jnainchi_InchiOptions(logger, nativeMol, options);
} finally {
$I$(5).IXA_MOL_Destroy$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_MOL_HANDLE(logger, nativeMol);
$I$(5).IXA_STATUS_Destroy$io_github_dan2097_jnainchi_inchi_IxaFunctions_IXA_STATUS_HANDLE(logger);
}
}, 1);

Clazz.newMeth(C$, 'inchiToInchiKey$S',  function (inchi) {
C$.checkLibrary$();
var inchiKeyBytes=Clazz.array(Byte.TYPE, [28]);
var szXtra1Bytes=Clazz.array(Byte.TYPE, [65]);
var szXtra2Bytes=Clazz.array(Byte.TYPE, [65]);
var ret=$I$(16,"of$I",[$I$(3).GetINCHIKeyFromINCHI$S$I$I$BA$BA$BA(inchi, 1, 1, inchiKeyBytes, szXtra1Bytes, szXtra2Bytes)]);
var inchiKeyStr= String.instantialize(inchiKeyBytes, $I$(17).UTF_8).trim$();
var szXtra1= String.instantialize(szXtra1Bytes, $I$(17).UTF_8).trim$();
var szXtra2= String.instantialize(szXtra2Bytes, $I$(17).UTF_8).trim$();
return Clazz.new_($I$(18,1).c$$S$io_github_dan2097_jnainchi_InchiKeyStatus$S$S,[inchiKeyStr, ret, szXtra1, szXtra2]);
}, 1);

Clazz.newMeth(C$, 'checkInchi$S$Z',  function (inchi, strict) {
C$.checkLibrary$();
return $I$(19,"of$I",[$I$(3).CheckINCHI$S$Z(inchi, strict)]);
}, 1);

Clazz.newMeth(C$, 'checkInchiKey$S',  function (inchiKey) {
C$.checkLibrary$();
return $I$(20,"of$I",[$I$(3).CheckINCHIKey$S(inchiKey)]);
}, 1);

Clazz.newMeth(C$, 'getInchiInputFromAuxInfo$S$Z$Z',  function (auxInfo, doNotAddH, diffUnkUndfStereo) {
C$.checkLibrary$();
var pInp=Clazz.new_($I$(21,1));
var input=Clazz.new_($I$(22,1).c$$io_github_dan2097_jnainchi_inchi_tagINCHI_Input,[pInp]);
try {
var status=C$.getInchiStatus$I($I$(3).Get_inchi_Input_FromAuxInfo$S$Z$Z$io_github_dan2097_jnainchi_inchi_tagInchiInpData(auxInfo, doNotAddH, diffUnkUndfStereo, input));
var inchiInput=Clazz.new_($I$(23,1));
var populatedInput=input.pInp;
if (populatedInput.num_atoms > 0) {
var nativeAtoms=Clazz.array($I$(24), [populatedInput.num_atoms]);
populatedInput.atom.toArray$com_sun_jna_StructureA(nativeAtoms);
C$.nativeToJavaAtoms$io_github_dan2097_jnainchi_InchiInput$io_github_dan2097_jnainchi_inchi_tagInchiAtomA(inchiInput, nativeAtoms);
C$.nativeToJavaBonds$io_github_dan2097_jnainchi_InchiInput$io_github_dan2097_jnainchi_inchi_tagInchiAtomA(inchiInput, nativeAtoms);
}if (populatedInput.num_stereo0D > 0) {
var nativeStereos=Clazz.array($I$(25), [populatedInput.num_stereo0D]);
populatedInput.stereo0D.toArray$com_sun_jna_StructureA(nativeStereos);
C$.nativeToJavaStereos$io_github_dan2097_jnainchi_InchiInput$io_github_dan2097_jnainchi_inchi_tagINCHIStereo0DA(inchiInput, nativeStereos);
}var message=C$.toString$BA(input.szErrMsg);
var chiralFlag=null;
if (input.bChiral == 1) {
chiralFlag=Boolean.valueOf$Z(true);
} else if (input.bChiral == 2) {
chiralFlag=Boolean.valueOf$Z(false);
}return Clazz.new_($I$(26,1).c$$io_github_dan2097_jnainchi_InchiInput$Boolean$S$io_github_dan2097_jnainchi_InchiStatus,[inchiInput, chiralFlag, message, status]);
} finally {
$I$(3).Free_inchi_Input$io_github_dan2097_jnainchi_inchi_tagINCHI_Input(pInp);
input.clear$();
}
}, 1);

Clazz.newMeth(C$, 'getInchiInputFromInchi$S',  function (inchi) {
return C$.getInchiInputFromInchi$S$io_github_dan2097_jnainchi_InchiOptions(inchi, $I$(4).DEFAULT_OPTIONS);
}, 1);

Clazz.newMeth(C$, 'getInchiInputFromInchi$S$io_github_dan2097_jnainchi_InchiOptions',  function (inchi, options) {
C$.checkLibrary$();
var input=Clazz.new_([inchi, options.toString()],$I$(27,1).c$$S$S);
var output=Clazz.new_($I$(28,1));
try {
var status=C$.getInchiStatus$I($I$(3).GetStructFromINCHI$io_github_dan2097_jnainchi_inchi_tagINCHI_InputINCHI$io_github_dan2097_jnainchi_inchi_tagINCHI_OutputStruct(input, output));
var inchiInput=Clazz.new_($I$(23,1));
if (output.num_atoms > 0) {
var nativeAtoms=Clazz.array($I$(24), [output.num_atoms]);
output.atom.toArray$com_sun_jna_StructureA(nativeAtoms);
C$.nativeToJavaAtoms$io_github_dan2097_jnainchi_InchiInput$io_github_dan2097_jnainchi_inchi_tagInchiAtomA(inchiInput, nativeAtoms);
C$.nativeToJavaBonds$io_github_dan2097_jnainchi_InchiInput$io_github_dan2097_jnainchi_inchi_tagInchiAtomA(inchiInput, nativeAtoms);
}if (output.num_stereo0D > 0) {
var nativeStereos=Clazz.array($I$(25), [output.num_stereo0D]);
output.stereo0D.toArray$com_sun_jna_StructureA(nativeStereos);
C$.nativeToJavaStereos$io_github_dan2097_jnainchi_InchiInput$io_github_dan2097_jnainchi_inchi_tagINCHIStereo0DA(inchiInput, nativeStereos);
}var message=output.szMessage;
var log=output.szLog;
var nativeFlags=output.WarningFlags;
var warningFlags=Clazz.array(Long.TYPE, [2, 2]);
for (var i=0; i < nativeFlags.length; i++) {
var val=nativeFlags[i].longValue$();
switch (i) {
case 0:
warningFlags[0][0]=val;
break;
case 1:
warningFlags[0][1]=val;
break;
case 2:
warningFlags[1][0]=val;
break;
case 3:
warningFlags[1][1]=val;
break;
default:
break;
}
}
return Clazz.new_($I$(29,1).c$$io_github_dan2097_jnainchi_InchiInput$S$S$io_github_dan2097_jnainchi_InchiStatus$JAA,[inchiInput, message, log, status, warningFlags]);
} finally {
$I$(3).FreeStructFromINCHI$io_github_dan2097_jnainchi_inchi_tagINCHI_OutputStruct(output);
input.clear$();
}
}, 1);

Clazz.newMeth(C$, 'nativeToJavaAtoms$io_github_dan2097_jnainchi_InchiInput$io_github_dan2097_jnainchi_inchi_tagInchiAtomA',  function (inchiInput, nativeAtoms) {
for (var i=0, numAtoms=nativeAtoms.length; i < numAtoms; i++) {
var nativeAtom=nativeAtoms[i];
var elSymbol=C$.toString$BA(nativeAtom.elname);
var atom=Clazz.new_($I$(30,1).c$$S,[elSymbol]);
atom.setX$D(nativeAtom.x);
atom.setY$D(nativeAtom.y);
atom.setZ$D(nativeAtom.z);
atom.setImplicitHydrogen$I(nativeAtom.num_iso_H[0]);
atom.setImplicitProtium$I(nativeAtom.num_iso_H[1]);
atom.setImplicitDeuterium$I(nativeAtom.num_iso_H[2]);
atom.setImplicitTritium$I(nativeAtom.num_iso_H[3]);
var isotopicMass=nativeAtom.isotopic_mass;
if (isotopicMass >= 9900 && isotopicMass <= 10100 ) {
var baseMass=(C$.inchiBaseAtomicMasses.getOrDefault$O$O(elSymbol, Integer.valueOf$I(0))).$c();
var delta=isotopicMass - 10000;
isotopicMass=baseMass + delta;
}atom.setIsotopicMass$I(isotopicMass);
atom.setRadical$io_github_dan2097_jnainchi_InchiRadical($I$(6).of$B(nativeAtom.radical));
atom.setCharge$I(nativeAtom.charge);
inchiInput.addAtom$io_github_dan2097_jnainchi_InchiAtom(atom);
}
}, 1);

Clazz.newMeth(C$, 'nativeToJavaBonds$io_github_dan2097_jnainchi_InchiInput$io_github_dan2097_jnainchi_inchi_tagInchiAtomA',  function (inchiInput, nativeAtoms) {
var numAtoms=nativeAtoms.length;
var seenAtoms=Clazz.array(Boolean.TYPE, [numAtoms]);
for (var i=0; i < numAtoms; i++) {
var nativeAtom=nativeAtoms[i];
var numBonds=nativeAtom.num_bonds;
if (numBonds > 0) {
var atom=inchiInput.getAtom$I(i);
for (var j=0; j < numBonds; j++) {
var neighborIdx=nativeAtom.neighbor[j];
if (seenAtoms[neighborIdx]) {
continue;
}var neighbor=inchiInput.getAtom$I(neighborIdx);
var bondType=$I$(7).of$B(nativeAtom.bond_type[j]);
var bondStereo=$I$(8).of$B(nativeAtom.bond_stereo[j]);
inchiInput.addBond$io_github_dan2097_jnainchi_InchiBond(Clazz.new_($I$(31,1).c$$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiBondType$io_github_dan2097_jnainchi_InchiBondStereo,[atom, neighbor, bondType, bondStereo]));
}
}seenAtoms[i]=true;
}
}, 1);

Clazz.newMeth(C$, 'nativeToJavaStereos$io_github_dan2097_jnainchi_InchiInput$io_github_dan2097_jnainchi_inchi_tagINCHIStereo0DA',  function (inchiInput, nativeStereos) {
for (var nativeStereo, $nativeStereo = 0, $$nativeStereo = nativeStereos; $nativeStereo<$$nativeStereo.length&&((nativeStereo=($$nativeStereo[$nativeStereo])),1);$nativeStereo++) {
var atoms=Clazz.array($I$(30), [4]);
for (var i=0; i < 4; i++) {
var idx=nativeStereo.neighbor[i];
atoms[i]=idx >= 0 ? inchiInput.getAtom$I(idx) : null;
}
var centralAtom=nativeStereo.central_atom >= 0 ? inchiInput.getAtom$I(nativeStereo.central_atom) : null;
var stereoType=$I$(9).of$B(nativeStereo.type);
var parity=$I$(32).of$B(nativeStereo.parity);
inchiInput.addStereo$io_github_dan2097_jnainchi_InchiStereo(Clazz.new_($I$(10,1).c$$io_github_dan2097_jnainchi_InchiAtomA$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiStereoType$io_github_dan2097_jnainchi_InchiStereoParity,[atoms, centralAtom, stereoType, parity]));
}
}, 1);

Clazz.newMeth(C$, 'getInchiStatus$I',  function (ret) {
switch (ret) {
case 0:
return $I$(12).SUCCESS;
case -1:
case 1:
return $I$(12).WARNING;
case 2:
case 3:
case 4:
case 5:
return $I$(12).ERROR;
default:
return $I$(12).ERROR;
}
}, 1);

Clazz.newMeth(C$, 'toString$BA',  function (cstr) {
var sb=Clazz.new_($I$(13,1).c$$I,[cstr.length]);
for (var i=0; i < cstr.length; i++) {
var ch=String.fromCharCode(cstr[i]);
if (ch == "\u0000") {
break;
}sb.append$C(ch);
}
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'getInchiLibraryVersion$',  function () {
try {
var is=Clazz.getClass(C$).getResourceAsStream$S("jnainchi_build.props");
try {
var props=Clazz.new_($I$(33,1));
props.load$java_io_InputStream(is);
return props.getProperty$S("inchi_version");

}finally{/*res*/is&&is.close$&&is.close$();}
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
return null;
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'getJnaInchiVersion$',  function () {
try {
var is=Clazz.getClass(C$).getResourceAsStream$S("jnainchi_build.props");
try {
var props=Clazz.new_($I$(33,1));
props.load$java_io_InputStream(is);
return props.getProperty$S("jnainchi_version");

}finally{/*res*/is&&is.close$&&is.close$();}
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
return null;
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'checkLibrary$',  function () {
if (C$.libraryLoadingError != null ) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S$Throwable,["Error loading InChI native code. Please check that the binaries for your platform (" + C$.platform + ") have been included on the classpath." , C$.libraryLoadingError]);
}}, 1);

C$.$static$=function(){C$.$static$=0;
C$.inchiBaseAtomicMasses=Clazz.new_($I$(1,1));
{
var t=null;
var p=null;
try {
p=$I$(2).RESOURCE_PREFIX;
$I$(3).JNA_NATIVE_LIB.getName$();
} catch (e) {
t=e;
}
C$.platform=p;
C$.libraryLoadingError=t;
C$.inchiBaseAtomicMasses.put$O$O("H", Integer.valueOf$I(1));
C$.inchiBaseAtomicMasses.put$O$O("D", Integer.valueOf$I(2));
C$.inchiBaseAtomicMasses.put$O$O("T", Integer.valueOf$I(3));
C$.inchiBaseAtomicMasses.put$O$O("He", Integer.valueOf$I(4));
C$.inchiBaseAtomicMasses.put$O$O("Li", Integer.valueOf$I(7));
C$.inchiBaseAtomicMasses.put$O$O("Be", Integer.valueOf$I(9));
C$.inchiBaseAtomicMasses.put$O$O("B", Integer.valueOf$I(11));
C$.inchiBaseAtomicMasses.put$O$O("C", Integer.valueOf$I(12));
C$.inchiBaseAtomicMasses.put$O$O("N", Integer.valueOf$I(14));
C$.inchiBaseAtomicMasses.put$O$O("O", Integer.valueOf$I(16));
C$.inchiBaseAtomicMasses.put$O$O("F", Integer.valueOf$I(19));
C$.inchiBaseAtomicMasses.put$O$O("Ne", Integer.valueOf$I(20));
C$.inchiBaseAtomicMasses.put$O$O("Na", Integer.valueOf$I(23));
C$.inchiBaseAtomicMasses.put$O$O("Mg", Integer.valueOf$I(24));
C$.inchiBaseAtomicMasses.put$O$O("Al", Integer.valueOf$I(27));
C$.inchiBaseAtomicMasses.put$O$O("Si", Integer.valueOf$I(28));
C$.inchiBaseAtomicMasses.put$O$O("P", Integer.valueOf$I(31));
C$.inchiBaseAtomicMasses.put$O$O("S", Integer.valueOf$I(32));
C$.inchiBaseAtomicMasses.put$O$O("Cl", Integer.valueOf$I(35));
C$.inchiBaseAtomicMasses.put$O$O("Ar", Integer.valueOf$I(40));
C$.inchiBaseAtomicMasses.put$O$O("K", Integer.valueOf$I(39));
C$.inchiBaseAtomicMasses.put$O$O("Ca", Integer.valueOf$I(40));
C$.inchiBaseAtomicMasses.put$O$O("Sc", Integer.valueOf$I(45));
C$.inchiBaseAtomicMasses.put$O$O("Ti", Integer.valueOf$I(48));
C$.inchiBaseAtomicMasses.put$O$O("V", Integer.valueOf$I(51));
C$.inchiBaseAtomicMasses.put$O$O("Cr", Integer.valueOf$I(52));
C$.inchiBaseAtomicMasses.put$O$O("Mn", Integer.valueOf$I(55));
C$.inchiBaseAtomicMasses.put$O$O("Fe", Integer.valueOf$I(56));
C$.inchiBaseAtomicMasses.put$O$O("Co", Integer.valueOf$I(59));
C$.inchiBaseAtomicMasses.put$O$O("Ni", Integer.valueOf$I(59));
C$.inchiBaseAtomicMasses.put$O$O("Cu", Integer.valueOf$I(64));
C$.inchiBaseAtomicMasses.put$O$O("Zn", Integer.valueOf$I(65));
C$.inchiBaseAtomicMasses.put$O$O("Ga", Integer.valueOf$I(70));
C$.inchiBaseAtomicMasses.put$O$O("Ge", Integer.valueOf$I(73));
C$.inchiBaseAtomicMasses.put$O$O("As", Integer.valueOf$I(75));
C$.inchiBaseAtomicMasses.put$O$O("Se", Integer.valueOf$I(79));
C$.inchiBaseAtomicMasses.put$O$O("Br", Integer.valueOf$I(80));
C$.inchiBaseAtomicMasses.put$O$O("Kr", Integer.valueOf$I(84));
C$.inchiBaseAtomicMasses.put$O$O("Rb", Integer.valueOf$I(85));
C$.inchiBaseAtomicMasses.put$O$O("Sr", Integer.valueOf$I(88));
C$.inchiBaseAtomicMasses.put$O$O("Y", Integer.valueOf$I(89));
C$.inchiBaseAtomicMasses.put$O$O("Zr", Integer.valueOf$I(91));
C$.inchiBaseAtomicMasses.put$O$O("Nb", Integer.valueOf$I(93));
C$.inchiBaseAtomicMasses.put$O$O("Mo", Integer.valueOf$I(96));
C$.inchiBaseAtomicMasses.put$O$O("Tc", Integer.valueOf$I(98));
C$.inchiBaseAtomicMasses.put$O$O("Ru", Integer.valueOf$I(101));
C$.inchiBaseAtomicMasses.put$O$O("Rh", Integer.valueOf$I(103));
C$.inchiBaseAtomicMasses.put$O$O("Pd", Integer.valueOf$I(106));
C$.inchiBaseAtomicMasses.put$O$O("Ag", Integer.valueOf$I(108));
C$.inchiBaseAtomicMasses.put$O$O("Cd", Integer.valueOf$I(112));
C$.inchiBaseAtomicMasses.put$O$O("In", Integer.valueOf$I(115));
C$.inchiBaseAtomicMasses.put$O$O("Sn", Integer.valueOf$I(119));
C$.inchiBaseAtomicMasses.put$O$O("Sb", Integer.valueOf$I(122));
C$.inchiBaseAtomicMasses.put$O$O("Te", Integer.valueOf$I(128));
C$.inchiBaseAtomicMasses.put$O$O("I", Integer.valueOf$I(127));
C$.inchiBaseAtomicMasses.put$O$O("Xe", Integer.valueOf$I(131));
C$.inchiBaseAtomicMasses.put$O$O("Cs", Integer.valueOf$I(133));
C$.inchiBaseAtomicMasses.put$O$O("Ba", Integer.valueOf$I(137));
C$.inchiBaseAtomicMasses.put$O$O("La", Integer.valueOf$I(139));
C$.inchiBaseAtomicMasses.put$O$O("Ce", Integer.valueOf$I(140));
C$.inchiBaseAtomicMasses.put$O$O("Pr", Integer.valueOf$I(141));
C$.inchiBaseAtomicMasses.put$O$O("Nd", Integer.valueOf$I(144));
C$.inchiBaseAtomicMasses.put$O$O("Pm", Integer.valueOf$I(145));
C$.inchiBaseAtomicMasses.put$O$O("Sm", Integer.valueOf$I(150));
C$.inchiBaseAtomicMasses.put$O$O("Eu", Integer.valueOf$I(152));
C$.inchiBaseAtomicMasses.put$O$O("Gd", Integer.valueOf$I(157));
C$.inchiBaseAtomicMasses.put$O$O("Tb", Integer.valueOf$I(159));
C$.inchiBaseAtomicMasses.put$O$O("Dy", Integer.valueOf$I(163));
C$.inchiBaseAtomicMasses.put$O$O("Ho", Integer.valueOf$I(165));
C$.inchiBaseAtomicMasses.put$O$O("Er", Integer.valueOf$I(167));
C$.inchiBaseAtomicMasses.put$O$O("Tm", Integer.valueOf$I(169));
C$.inchiBaseAtomicMasses.put$O$O("Yb", Integer.valueOf$I(173));
C$.inchiBaseAtomicMasses.put$O$O("Lu", Integer.valueOf$I(175));
C$.inchiBaseAtomicMasses.put$O$O("Hf", Integer.valueOf$I(178));
C$.inchiBaseAtomicMasses.put$O$O("Ta", Integer.valueOf$I(181));
C$.inchiBaseAtomicMasses.put$O$O("W", Integer.valueOf$I(184));
C$.inchiBaseAtomicMasses.put$O$O("Re", Integer.valueOf$I(186));
C$.inchiBaseAtomicMasses.put$O$O("Os", Integer.valueOf$I(190));
C$.inchiBaseAtomicMasses.put$O$O("Ir", Integer.valueOf$I(192));
C$.inchiBaseAtomicMasses.put$O$O("Pt", Integer.valueOf$I(195));
C$.inchiBaseAtomicMasses.put$O$O("Au", Integer.valueOf$I(197));
C$.inchiBaseAtomicMasses.put$O$O("Hg", Integer.valueOf$I(201));
C$.inchiBaseAtomicMasses.put$O$O("Tl", Integer.valueOf$I(204));
C$.inchiBaseAtomicMasses.put$O$O("Pb", Integer.valueOf$I(207));
C$.inchiBaseAtomicMasses.put$O$O("Bi", Integer.valueOf$I(209));
C$.inchiBaseAtomicMasses.put$O$O("Po", Integer.valueOf$I(209));
C$.inchiBaseAtomicMasses.put$O$O("At", Integer.valueOf$I(210));
C$.inchiBaseAtomicMasses.put$O$O("Rn", Integer.valueOf$I(222));
C$.inchiBaseAtomicMasses.put$O$O("Fr", Integer.valueOf$I(223));
C$.inchiBaseAtomicMasses.put$O$O("Ra", Integer.valueOf$I(226));
C$.inchiBaseAtomicMasses.put$O$O("Ac", Integer.valueOf$I(227));
C$.inchiBaseAtomicMasses.put$O$O("Th", Integer.valueOf$I(232));
C$.inchiBaseAtomicMasses.put$O$O("Pa", Integer.valueOf$I(231));
C$.inchiBaseAtomicMasses.put$O$O("U", Integer.valueOf$I(238));
C$.inchiBaseAtomicMasses.put$O$O("Np", Integer.valueOf$I(237));
C$.inchiBaseAtomicMasses.put$O$O("Pu", Integer.valueOf$I(244));
C$.inchiBaseAtomicMasses.put$O$O("Am", Integer.valueOf$I(243));
C$.inchiBaseAtomicMasses.put$O$O("Cm", Integer.valueOf$I(247));
C$.inchiBaseAtomicMasses.put$O$O("Bk", Integer.valueOf$I(247));
C$.inchiBaseAtomicMasses.put$O$O("Cf", Integer.valueOf$I(251));
C$.inchiBaseAtomicMasses.put$O$O("Es", Integer.valueOf$I(252));
C$.inchiBaseAtomicMasses.put$O$O("Fm", Integer.valueOf$I(257));
C$.inchiBaseAtomicMasses.put$O$O("Md", Integer.valueOf$I(258));
C$.inchiBaseAtomicMasses.put$O$O("No", Integer.valueOf$I(259));
C$.inchiBaseAtomicMasses.put$O$O("Lr", Integer.valueOf$I(260));
C$.inchiBaseAtomicMasses.put$O$O("Rf", Integer.valueOf$I(261));
C$.inchiBaseAtomicMasses.put$O$O("Db", Integer.valueOf$I(270));
C$.inchiBaseAtomicMasses.put$O$O("Sg", Integer.valueOf$I(269));
C$.inchiBaseAtomicMasses.put$O$O("Bh", Integer.valueOf$I(270));
C$.inchiBaseAtomicMasses.put$O$O("Hs", Integer.valueOf$I(270));
C$.inchiBaseAtomicMasses.put$O$O("Mt", Integer.valueOf$I(278));
C$.inchiBaseAtomicMasses.put$O$O("Ds", Integer.valueOf$I(281));
C$.inchiBaseAtomicMasses.put$O$O("Rg", Integer.valueOf$I(281));
C$.inchiBaseAtomicMasses.put$O$O("Cn", Integer.valueOf$I(285));
C$.inchiBaseAtomicMasses.put$O$O("Nh", Integer.valueOf$I(278));
C$.inchiBaseAtomicMasses.put$O$O("Fl", Integer.valueOf$I(289));
C$.inchiBaseAtomicMasses.put$O$O("Mc", Integer.valueOf$I(289));
C$.inchiBaseAtomicMasses.put$O$O("Lv", Integer.valueOf$I(293));
C$.inchiBaseAtomicMasses.put$O$O("Ts", Integer.valueOf$I(297));
C$.inchiBaseAtomicMasses.put$O$O("Og", Integer.valueOf$I(294));
};
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-12 18:04:23 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
