(function(){var P$=Clazz.newPackage("io.github.dan2097.jnainchi"),I$=[[0,'java.util.EnumSet','io.github.dan2097.jnainchi.InchiFlag','io.github.dan2097.jnainchi.InchiOptions',['io.github.dan2097.jnainchi.InchiOptions','.InchiOptionsBuilder'],'java.util.Locale','java.util.Collections','java.util.ArrayList','StringBuilder']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "InchiOptions", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['InchiOptionsBuilder',9]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['J',['timeoutMilliSecs'],'O',['flags','java.util.List']]
,['Z',['IS_WINDOWS'],'O',['DEFAULT_OPTIONS','io.github.dan2097.jnainchi.InchiOptions']]]

Clazz.newMeth(C$, 'c$$io_github_dan2097_jnainchi_InchiOptions_InchiOptionsBuilder',  function (builder) {
;C$.$init$.apply(this);
this.flags=$I$(6,"unmodifiableList$java_util_List",[Clazz.new_($I$(7,1).c$$java_util_Collection,[builder.flags])]);
this.timeoutMilliSecs=builder.timeoutMilliSecs;
}, 1);

Clazz.newMeth(C$, 'getFlags$',  function () {
return this.flags;
});

Clazz.newMeth(C$, 'getTimeout$',  function () {
return Long.$ival((Long.$div(this.timeoutMilliSecs,1000)));
});

Clazz.newMeth(C$, 'getTimeoutMilliSeconds$',  function () {
return this.timeoutMilliSecs;
});

Clazz.newMeth(C$, 'toString',  function () {
var sb=Clazz.new_($I$(8,1));
for (var inchiFlag, $inchiFlag = this.flags.iterator$(); $inchiFlag.hasNext$()&&((inchiFlag=($inchiFlag.next$())),1);) {
if (inchiFlag === $I$(2).SAbs ) {
continue;
}if (sb.length$() > 0) {
sb.append$C(" ");
}sb.append$S(C$.IS_WINDOWS ? "/" : "-");
sb.append$S(inchiFlag.toString());
}
if (Long.$ne(this.timeoutMilliSecs,0 )) {
if (sb.length$() > 0) {
sb.append$C(" ");
}sb.append$S(C$.IS_WINDOWS ? "/" : "-");
sb.append$S("WM");
sb.append$S(String.valueOf$J(this.timeoutMilliSecs));
}return sb.toString();
});

C$.$static$=function(){C$.$static$=0;
C$.DEFAULT_OPTIONS=Clazz.new_($I$(4,1)).build$();
C$.IS_WINDOWS=System.getProperty$S$S("os.name", "").toLowerCase$java_util_Locale($I$(5).ROOT).startsWith$S("windows");
};
;
(function(){/*c*/var C$=Clazz.newClass(P$.InchiOptions, "InchiOptionsBuilder", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.flags=$I$(1,"noneOf$Class",[Clazz.getClass($I$(2))]);
this.timeoutMilliSecs=0;
},1);

C$.$fields$=[['J',['timeoutMilliSecs'],'O',['flags','java.util.EnumSet']]]

Clazz.newMeth(C$, 'withFlag$io_github_dan2097_jnainchi_InchiFlagA',  function (flags) {
for (var flag, $flag = 0, $$flag = flags; $flag<$$flag.length&&((flag=($$flag[$flag])),1);$flag++) {
this.flags.add$O(flag);
}
return this;
});

Clazz.newMeth(C$, 'withTimeout$I',  function (timeoutSecs) {
if (timeoutSecs < 0) {
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["Timeout should be a time in seconds or 0 for infinite: " + timeoutSecs]);
}this.timeoutMilliSecs=Long.$mul(timeoutSecs,1000);
return this;
});

Clazz.newMeth(C$, 'withTimeoutMilliSeconds$J',  function (timeoutMilliSecs) {
if (Long.$lt(timeoutMilliSecs,0 )) {
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["Timeout should be a time in milliseconds or 0 for infinite: " + Long.$s(timeoutMilliSecs)]);
}this.timeoutMilliSecs=timeoutMilliSecs;
return this;
});

Clazz.newMeth(C$, 'build$',  function () {
var stereoOptionFlags=0;
var chiralFlagFlags=0;
for (var flag, $flag = this.flags.iterator$(); $flag.hasNext$()&&((flag=($flag.next$())),1);) {
switch (flag) {
case $I$(2).SNon:
case $I$(2).SRac:
case $I$(2).SRel:
case $I$(2).SUCF:
case $I$(2).SAbs:
++stereoOptionFlags;
break;
case $I$(2).ChiralFlagOFF:
case $I$(2).ChiralFlagON:
++chiralFlagFlags;
break;
default:
break;
}
}
if (stereoOptionFlags > 1) {
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["Ambiguous flags: SAbs, SNon, SRel, SRac and SUCF are mutually exclusive"]);
}if (chiralFlagFlags > 1) {
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["Ambiguous flags: ChiralFlagOFF and ChiralFlagON are mutually exclusive"]);
}return Clazz.new_($I$(3,1).c$$io_github_dan2097_jnainchi_InchiOptions_InchiOptionsBuilder,[this]);
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-02 04:53:14 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
