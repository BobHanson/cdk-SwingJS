(function(){var P$=Clazz.newPackage("io.github.dan2097.jnainchi"),I$=[[0,'io.github.dan2097.jnainchi.InchiRadical']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "InchiAtom");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.x=0;
this.y=0;
this.z=0;
this.implicitHydrogen=Clazz.array(Integer.TYPE, [4]);
this.isotopicMass=0;
this.radical=$I$(1).NONE;
this.charge=0;
},1);

C$.$fields$=[['D',['x','y','z'],'I',['isotopicMass','charge'],'S',['elName'],'O',['implicitHydrogen','int[]','radical','io.github.dan2097.jnainchi.InchiRadical']]]

Clazz.newMeth(C$, 'c$$S',  function (elName) {
;C$.$init$.apply(this);
this.elName=elName;
}, 1);

Clazz.newMeth(C$, 'c$$S$D$D$D',  function (elName, x, y, z) {
;C$.$init$.apply(this);
this.elName=elName;
this.x=x;
this.y=y;
this.z=z;
}, 1);

Clazz.newMeth(C$, 'getElName$',  function () {
return this.elName;
});

Clazz.newMeth(C$, 'setElName$S',  function (elName) {
this.elName=elName;
});

Clazz.newMeth(C$, 'getX$',  function () {
return this.x;
});

Clazz.newMeth(C$, 'setX$D',  function (x) {
this.x=x;
});

Clazz.newMeth(C$, 'getY$',  function () {
return this.y;
});

Clazz.newMeth(C$, 'setY$D',  function (y) {
this.y=y;
});

Clazz.newMeth(C$, 'getZ$',  function () {
return this.z;
});

Clazz.newMeth(C$, 'setZ$D',  function (z) {
this.z=z;
});

Clazz.newMeth(C$, 'getImplicitHydrogen$',  function () {
return this.implicitHydrogen[0];
});

Clazz.newMeth(C$, 'setImplicitHydrogen$I',  function (implicitHydrogen) {
if (implicitHydrogen > 127 || implicitHydrogen < -1 ) {
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["Unacceptable implicitHydrogen:" + implicitHydrogen]);
}this.implicitHydrogen[0]=implicitHydrogen;
});

Clazz.newMeth(C$, 'setImplicitProtium$I',  function (implicitProtium) {
if (implicitProtium > 127 || implicitProtium < 0 ) {
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["Unacceptable implicitProtium:" + implicitProtium]);
}this.implicitHydrogen[1]=implicitProtium;
});

Clazz.newMeth(C$, 'getImplicitProtium$',  function () {
return this.implicitHydrogen[1];
});

Clazz.newMeth(C$, 'setImplicitDeuterium$I',  function (implicitDeuterium) {
if (implicitDeuterium > 127 || implicitDeuterium < 0 ) {
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["Unacceptable implicitDeuterium:" + implicitDeuterium]);
}this.implicitHydrogen[2]=implicitDeuterium;
});

Clazz.newMeth(C$, 'getImplicitDeuterium$',  function () {
return this.implicitHydrogen[2];
});

Clazz.newMeth(C$, 'setImplicitTritium$I',  function (implicitTritium) {
if (implicitTritium > 127 || implicitTritium < 0 ) {
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["Unacceptable implicitTritium:" + implicitTritium]);
}this.implicitHydrogen[3]=implicitTritium;
});

Clazz.newMeth(C$, 'getImplicitTritium$',  function () {
return this.implicitHydrogen[3];
});

Clazz.newMeth(C$, 'getIsotopicMass$',  function () {
return this.isotopicMass;
});

Clazz.newMeth(C$, 'setIsotopicMass$I',  function (isotopicMass) {
if (isotopicMass > 32767 || isotopicMass < 0 ) {
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["Unacceptable isotopicMass:" + isotopicMass]);
}this.isotopicMass=isotopicMass;
});

Clazz.newMeth(C$, 'getRadical$',  function () {
return this.radical;
});

Clazz.newMeth(C$, 'setRadical$io_github_dan2097_jnainchi_InchiRadical',  function (radical) {
this.radical=radical;
});

Clazz.newMeth(C$, 'getCharge$',  function () {
return this.charge;
});

Clazz.newMeth(C$, 'setCharge$I',  function (charge) {
if (charge > 127 || charge < -128 ) {
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["Unacceptable charge:" + charge]);
}this.charge=charge;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v6');//Created 2025-03-17 21:43:21 Java2ScriptVisitor version 5.0.1-v6 net.sf.j2s.core.jar version 5.0.1-v6
