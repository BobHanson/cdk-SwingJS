(function(){var P$=Clazz.newPackage("io.github.dan2097.jnainchi"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "InchiInputFromAuxinfoOutput");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['message'],'O',['inchiInput','io.github.dan2097.jnainchi.InchiInput','chiralFlag','Boolean','status','io.github.dan2097.jnainchi.InchiStatus']]]

Clazz.newMeth(C$, 'c$$io_github_dan2097_jnainchi_InchiInput$Boolean$S$io_github_dan2097_jnainchi_InchiStatus',  function (inchiInput, chiralFlag, message, status) {
;C$.$init$.apply(this);
this.inchiInput=inchiInput;
this.chiralFlag=chiralFlag;
this.message=message;
this.status=status;
}, 1);

Clazz.newMeth(C$, 'getInchiInput$',  function () {
return this.inchiInput;
});

Clazz.newMeth(C$, 'getChiralFlag$',  function () {
return this.chiralFlag;
});

Clazz.newMeth(C$, 'getMessage$',  function () {
return this.message;
});

Clazz.newMeth(C$, 'getStatus$',  function () {
return this.status;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v6');//Created 2025-03-21 12:04:23 Java2ScriptVisitor version 5.0.1-v6 net.sf.j2s.core.jar version 5.0.1-v6
