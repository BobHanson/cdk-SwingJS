(function(){var P$=Clazz.newPackage("io.github.dan2097.jnainchi"),I$=[[0,'java.util.HashMap','com.sun.jna.Platform','io.github.dan2097.jnainchi.inchi.InchiLibrary','io.github.dan2097.jnainchi.InchiOptions','io.github.dan2097.jnainchi.inchi.IXA','io.github.dan2097.jnainchi.InchiRadical','io.github.dan2097.jnainchi.InchiBondType','io.github.dan2097.jnainchi.InchiBondStereo','io.github.dan2097.jnainchi.InchiStereoType','io.github.dan2097.jnainchi.InchiStereoParity','io.github.dan2097.jnainchi.InchiStereo','io.github.dan2097.jnainchi.InchiFlag','io.github.dan2097.jnainchi.InchiOutput','io.github.dan2097.jnainchi.InchiStatus','StringBuilder','io.github.dan2097.jnainchi.InchiKeyOutput','io.github.dan2097.jnainchi.InchiKeyStatus','io.github.dan2097.jnainchi.InchiCheckStatus','io.github.dan2097.jnainchi.InchiKeyCheckStatus','io.github.dan2097.jnainchi.InchiInput','io.github.dan2097.jnainchi.InchiInputFromAuxinfoOutput','io.github.dan2097.jnainchi.InchiInputFromInchiOutput','io.github.dan2097.jnainchi.InchiAtom','io.github.dan2097.jnainchi.InchiBond','io.github.dan2097.jnainchi.JnaInchi','java.util.Properties']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "InchIXA");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['Z',['isJS'],'O',['libraryLoadingError','Throwable','aveMass','java.util.Map']]]

Clazz.newMeth(C$, 'toInchi$io_github_dan2097_jnainchi_InchiInput',  function (inchiInput) {
return C$.toInchi$io_github_dan2097_jnainchi_InchiInput$io_github_dan2097_jnainchi_InchiOptions(inchiInput, $I$(4).DEFAULT_OPTIONS);
}, 1);

Clazz.newMeth(C$, 'toInchi$io_github_dan2097_jnainchi_InchiInput$io_github_dan2097_jnainchi_InchiOptions',  function (inchiInput, options) {
C$.checkLibrary$();
var atoms=inchiInput.getAtoms$();
var atomCount=atoms.size$();
if (atomCount > 32767) {
throw Clazz.new_(Clazz.load('IllegalStateException').c$$S,["InChI is limited to 32767 atoms, input contained " + atomCount + " atoms" ]);
}var bonds=inchiInput.getBonds$();
var stereos=inchiInput.getStereos$();
if (stereos.size$() > 32767) {
throw Clazz.new_(Clazz.load('IllegalStateException').c$$S,["Too many stereochemistry elements in input"]);
}var logger=$I$(5).IXA_STATUS_Create$();
var nativeMol=$I$(5).IXA_MOL_Create$O(logger);
$I$(5,"IXA_MOL_ReserveSpace$O$O$I$I$I",[logger, nativeMol, atomCount, bonds.size$(), stereos.size$()]);
try {
var atomToNativeAtom=C$.addAtoms$O$O$java_util_List(nativeMol, logger, atoms);
C$.addBonds$O$O$java_util_List$java_util_Map(nativeMol, logger, bonds, atomToNativeAtom);
C$.addStereos$O$O$java_util_List$java_util_Map(nativeMol, logger, stereos, atomToNativeAtom);
return C$.buildInchi$O$O$io_github_dan2097_jnainchi_InchiOptions(logger, nativeMol, options);
} finally {
$I$(5).IXA_MOL_Destroy$O$O(logger, nativeMol);
$I$(5).IXA_STATUS_Destroy$O(logger);
}
}, 1);

Clazz.newMeth(C$, 'addAtoms$O$O$java_util_List',  function (mol, logger, atoms) {
var atomToNativeAtom=Clazz.new_($I$(1,1));
for (var atom, $atom = atoms.iterator$(); $atom.hasNext$()&&((atom=($atom.next$())),1);) {
var v;
var iv;
var sv;
var nativeAtom=$I$(5).IXA_MOL_CreateAtom$O$O(logger, mol);
atomToNativeAtom.put$O$O(atom, nativeAtom);
if ((v=atom.getX$()) != 0 ) {
$I$(5).IXA_MOL_SetAtomX$O$O$O$D(logger, mol, nativeAtom, v);
}if ((v=atom.getY$()) != 0 ) {
$I$(5).IXA_MOL_SetAtomY$O$O$O$D(logger, mol, nativeAtom, v);
}if ((v=atom.getZ$()) != 0 ) {
$I$(5).IXA_MOL_SetAtomZ$O$O$O$D(logger, mol, nativeAtom, v);
}if (!(sv=atom.getElName$()).equals$O("C")) {
if (sv.length$() > 5) {
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["Element name was too long: " + sv]);
}$I$(5).IXA_MOL_SetAtomElement$O$O$O$S(logger, mol, nativeAtom, sv);
}if ((iv=atom.getIsotopicMass$()) != 0) {
$I$(5).IXA_MOL_SetAtomMass$O$O$O$I(logger, mol, nativeAtom, iv);
}if ((iv=atom.getCharge$()) != 0) {
$I$(5).IXA_MOL_SetAtomCharge$O$O$O$I(logger, mol, nativeAtom, iv);
}if ((iv=$I$(6,"getCodeObj$O",[atom.getRadical$()])) != 0) {
$I$(5).IXA_MOL_SetAtomRadical$O$O$O$I(logger, mol, nativeAtom, iv);
}if ((iv=atom.getImplicitHydrogen$()) != 0) {
$I$(5).IXA_MOL_SetAtomHydrogens$O$O$O$I$I(logger, mol, nativeAtom, 0, iv);
}if ((iv=atom.getImplicitProtium$()) != 0) {
$I$(5).IXA_MOL_SetAtomHydrogens$O$O$O$I$I(logger, mol, nativeAtom, 1, iv);
}if ((iv=atom.getImplicitDeuterium$()) != 0) {
$I$(5).IXA_MOL_SetAtomHydrogens$O$O$O$I$I(logger, mol, nativeAtom, 2, iv);
}if ((iv=atom.getImplicitTritium$()) != 0) {
$I$(5).IXA_MOL_SetAtomHydrogens$O$O$O$I$I(logger, mol, nativeAtom, 3, iv);
}}
return atomToNativeAtom;
}, 1);

Clazz.newMeth(C$, 'getStr$S$S',  function (s, defNull) {
return (s == null  || s.equalsIgnoreCase$S(defNull)  ? null : s.toLowerCase$());
}, 1);

Clazz.newMeth(C$, 'addBonds$O$O$java_util_List$java_util_Map',  function (mol, logger, bonds, atomToNativeAtom) {
for (var bond, $bond = bonds.iterator$(); $bond.hasNext$()&&((bond=($bond.next$())),1);) {
var nativeAtom1=atomToNativeAtom.get$O(bond.getStart$());
var nativeAtom2=atomToNativeAtom.get$O(bond.getEnd$());
if (nativeAtom1 == null  || nativeAtom2 == null  ) {
throw Clazz.new_(Clazz.load('IllegalStateException').c$$S,["Bond referenced an atom that was not provided"]);
}var nativeBond=$I$(5).IXA_MOL_CreateBond$O$O$O$O(logger, mol, nativeAtom1, nativeAtom2);
var iv;
if ((iv=$I$(7,"getCodeObj$O",[bond.getType$()])) != 1) {
$I$(5).IXA_MOL_SetBondType$O$O$O$I(logger, mol, nativeBond, iv);
}switch (iv=$I$(8,"getCodeObj$O",[bond.getStereo$()])) {
case 3:
$I$(5).IXA_MOL_SetDblBondConfig$O$O$O$I(logger, mol, nativeBond, 1);
break;
case 6:
$I$(5).IXA_MOL_SetBondWedge$O$O$O$O$I(logger, mol, nativeBond, nativeAtom1, 2);
break;
case 4:
$I$(5).IXA_MOL_SetBondWedge$O$O$O$O$I(logger, mol, nativeBond, nativeAtom1, 3);
break;
case 1:
$I$(5).IXA_MOL_SetBondWedge$O$O$O$O$I(logger, mol, nativeBond, nativeAtom1, 1);
break;
case -6:
$I$(5).IXA_MOL_SetBondWedge$O$O$O$O$I(logger, mol, nativeBond, nativeAtom2, 2);
break;
case -4:
$I$(5).IXA_MOL_SetBondWedge$O$O$O$O$I(logger, mol, nativeBond, nativeAtom2, 3);
break;
case -1:
$I$(5).IXA_MOL_SetBondWedge$O$O$O$O$I(logger, mol, nativeBond, nativeAtom2, 1);
break;
default:
case 0:
break;
}
}
}, 1);

Clazz.newMeth(C$, 'addStereos$O$O$java_util_List$java_util_Map',  function (nativeMol, logger, stereos, atomToNativeAtom) {
for (var stereo, $stereo = stereos.iterator$(); $stereo.hasNext$()&&((stereo=($stereo.next$())),1);) {
var type=$I$(9,"getCodeObj$O",[stereo.getType$()]);
if (type == 0) {
continue;
}var neighbors=stereo.getAtoms$();
var vertex1=C$.getStereoVertex$java_util_Map$io_github_dan2097_jnainchi_InchiAtom(atomToNativeAtom, neighbors[0]);
var vertex2=C$.getStereoVertex$java_util_Map$io_github_dan2097_jnainchi_InchiAtom(atomToNativeAtom, neighbors[1]);
var vertex3=C$.getStereoVertex$java_util_Map$io_github_dan2097_jnainchi_InchiAtom(atomToNativeAtom, neighbors[2]);
var vertex4=C$.getStereoVertex$java_util_Map$io_github_dan2097_jnainchi_InchiAtom(atomToNativeAtom, neighbors[3]);
var center;
var centralAtom;
switch (type) {
case 2:
{
centralAtom=C$.getStereoCentralAtom$io_github_dan2097_jnainchi_InchiStereo$java_util_Map(stereo, atomToNativeAtom);
center=$I$(5).IXA_MOL_CreateStereoTetrahedron$O$O$O$O$O$O$O(logger, nativeMol, centralAtom, vertex1, vertex2, vertex3, vertex4);
break;
}case 3:
{
centralAtom=C$.getStereoCentralAtom$io_github_dan2097_jnainchi_InchiStereo$java_util_Map(stereo, atomToNativeAtom);
center=$I$(5).IXA_MOL_CreateStereoAntiRectangle$O$O$O$O$O$O$O(logger, nativeMol, centralAtom, vertex1, vertex2, vertex3, vertex4);
break;
}case 1:
{
var centralBond=$I$(5).IXA_MOL_GetCommonBond$O$O$O$O(logger, nativeMol, vertex2, vertex3);
if (centralBond == null ) {
throw Clazz.new_(Clazz.load('IllegalStateException').c$$S,["Could not find olefin/cumulene central bond"]);
}center=$I$(5,"IXA_MOL_CreateStereoRectangle$O$O$O$O$O$O$O",[logger, nativeMol, centralBond, vertex1, $I$(5).ATOM_IMPLICIT_H, $I$(5).ATOM_IMPLICIT_H, vertex4]);
break;
}default:
throw Clazz.new_(Clazz.load('IllegalStateException').c$$S,["Unexpected InChI stereo type:" + type]);
}
var parity=$I$(10,"getCodeObj$O",[stereo.getParity$()]);
$I$(5).IXA_MOL_SetStereoParity$O$O$O$I(logger, nativeMol, center, parity);
}
}, 1);

Clazz.newMeth(C$, 'getStereoCentralAtom$io_github_dan2097_jnainchi_InchiStereo$java_util_Map',  function (stereo, atomToNativeAtom) {
var centralAtom=stereo.getCentralAtom$();
var nativeCentral=atomToNativeAtom.get$O(centralAtom);
if (nativeCentral == null ) {
throw Clazz.new_(Clazz.load('IllegalStateException').c$$S,["Stereo configuration central atom referenced an atom that does not exist"]);
}return C$.toPointer$O(nativeCentral);
}, 1);

Clazz.newMeth(C$, 'toPointer$O',  function (o) {
{
return o.intValue();
}
}, 1);

Clazz.newMeth(C$, 'getStereoVertex$java_util_Map$io_github_dan2097_jnainchi_InchiAtom',  function (atomToNativeAtom, inchiAtom) {
if ($I$(11).STEREO_IMPLICIT_H === inchiAtom ) {
return $I$(5).ATOM_IMPLICIT_H;
}var vertex=atomToNativeAtom.get$O(inchiAtom);
if (vertex == null ) {
throw Clazz.new_(Clazz.load('IllegalStateException').c$$S,["Stereo configuration referenced an atom that does not exist"]);
}return vertex;
}, 1);

Clazz.newMeth(C$, 'getNativeAtom$java_util_Map$O',  function (atomToNativeAtom, atom) {
var jsAtom=null;
if (Clazz.instanceOf(atom, "java.lang.Integer")) {

jsAtom = atom;
}var nativeAtom=atomToNativeAtom.get$O(atom);
if (nativeAtom == null ) {
throw Clazz.new_(Clazz.load('IllegalStateException').c$$S,["Stereo configuration referenced an atom that does not exist"]);
}return nativeAtom;
}, 1);

Clazz.newMeth(C$, 'buildInchi$O$O$io_github_dan2097_jnainchi_InchiOptions',  function (logger, nativeMol, options) {
var builder=$I$(5).IXA_INCHIBUILDER_Create$O(logger);
try {
$I$(5).IXA_INCHIBUILDER_SetMolecule$O$O$O(logger, builder, nativeMol);
var timeoutMilliSecs=options.getTimeoutMilliSeconds$();
if (Long.$ne(timeoutMilliSecs,0 )) {
$I$(5).IXA_INCHIBUILDER_SetOption_Timeout_MilliSeconds$O$O$J(logger, builder, timeoutMilliSecs);
}for (var flag, $flag = options.getFlags$().iterator$(); $flag.hasNext$()&&((flag=($flag.next$())),1);) {
switch (flag) {
case $I$(12).AuxNone:
$I$(5).IXA_INCHIBUILDER_SetOption$O$O$I$Z(logger, builder, 9, true);
break;
case $I$(12).ChiralFlagOFF:
$I$(5).IXA_MOL_SetChiral$O$O$Z(logger, nativeMol, false);
break;
case $I$(12).ChiralFlagON:
$I$(5).IXA_MOL_SetChiral$O$O$Z(logger, nativeMol, true);
break;
case $I$(12).DoNotAddH:
$I$(5).IXA_INCHIBUILDER_SetOption$O$O$I$Z(logger, builder, 1, true);
break;
case $I$(12).FixedH:
$I$(5).IXA_INCHIBUILDER_SetOption$O$O$I$Z(logger, builder, 4, true);
break;
case $I$(12).KET:
$I$(5).IXA_INCHIBUILDER_SetOption$O$O$I$Z(logger, builder, 6, true);
break;
case $I$(12).LargeMolecules:
$I$(5).IXA_INCHIBUILDER_SetOption$O$O$I$Z(logger, builder, 11, true);
break;
case $I$(12).NEWPSOFF:
$I$(5).IXA_INCHIBUILDER_SetOption$O$O$I$Z(logger, builder, 0, true);
break;
case $I$(12).OneFiveT:
$I$(5).IXA_INCHIBUILDER_SetOption$O$O$I$Z(logger, builder, 7, true);
break;
case $I$(12).RecMet:
$I$(5).IXA_INCHIBUILDER_SetOption$O$O$I$Z(logger, builder, 5, true);
break;
case $I$(12).SLUUD:
$I$(5).IXA_INCHIBUILDER_SetOption$O$O$I$Z(logger, builder, 3, true);
break;
case $I$(12).SNon:
$I$(5).IXA_INCHIBUILDER_SetOption_Stereo$O$O$I(logger, builder, 1);
break;
case $I$(12).SRac:
$I$(5).IXA_INCHIBUILDER_SetOption_Stereo$O$O$I(logger, builder, 3);
break;
case $I$(12).SRel:
$I$(5).IXA_INCHIBUILDER_SetOption_Stereo$O$O$I(logger, builder, 2);
break;
case $I$(12).SUCF:
$I$(5).IXA_INCHIBUILDER_SetOption_Stereo$O$O$I(logger, builder, 4);
break;
case $I$(12).SAbs:
$I$(5).IXA_INCHIBUILDER_SetOption_Stereo$O$O$I(logger, builder, 0);
break;
case $I$(12).SUU:
$I$(5).IXA_INCHIBUILDER_SetOption$O$O$I$Z(logger, builder, 2, true);
break;
case $I$(12).SaveOpt:
$I$(5).IXA_INCHIBUILDER_SetOption$O$O$I$Z(logger, builder, 8, true);
break;
case $I$(12).WarnOnEmptyStructure:
$I$(5).IXA_INCHIBUILDER_SetOption$O$O$I$Z(logger, builder, 10, true);
break;
case $I$(12).NoWarnings:
$I$(5).IXA_INCHIBUILDER_SetOption$O$O$I$Z(logger, builder, 24, true);
break;
case $I$(12).LooseTSACheck:
$I$(5).IXA_INCHIBUILDER_SetOption$O$O$I$Z(logger, builder, 22, true);
break;
case $I$(12).Polymers:
$I$(5).IXA_INCHIBUILDER_SetOption$O$O$I$Z(logger, builder, 12, true);
break;
case $I$(12).Polymers105:
$I$(5).IXA_INCHIBUILDER_SetOption$O$O$I$Z(logger, builder, 13, true);
break;
case $I$(12).FoldCRU:
$I$(5).IXA_INCHIBUILDER_SetOption$O$O$I$Z(logger, builder, 20, true);
break;
case $I$(12).NoFrameShift:
$I$(5).IXA_INCHIBUILDER_SetOption$O$O$I$Z(logger, builder, 19, true);
break;
case $I$(12).NoEdits:
$I$(5).IXA_INCHIBUILDER_SetOption$O$O$I$Z(logger, builder, 21, true);
break;
case $I$(12).NPZz:
$I$(5).IXA_INCHIBUILDER_SetOption$O$O$I$Z(logger, builder, 17, true);
break;
case $I$(12).SAtZz:
$I$(5).IXA_INCHIBUILDER_SetOption$O$O$I$Z(logger, builder, 18, true);
break;
case $I$(12).OutErrInChI:
$I$(5).IXA_INCHIBUILDER_SetOption$O$O$I$Z(logger, builder, 23, true);
break;
default:
throw Clazz.new_(Clazz.load('IllegalStateException').c$$S,["Unexpected InChI option flag: " + flag]);
}
}
var inchi=$I$(5).IXA_INCHIBUILDER_GetInChI$O$O(logger, builder);
var auxInfo=$I$(5).IXA_INCHIBUILDER_GetAuxInfo$O$O(logger, builder);
var log=$I$(5).IXA_INCHIBUILDER_GetLog$O$O(logger, builder);
var status=C$.getStatus$O(logger);
var messages=C$.getMessages$O(logger);
return Clazz.new_($I$(13,1).c$$S$S$S$S$io_github_dan2097_jnainchi_InchiStatus,[inchi, auxInfo, messages, log, status]);
} finally {
$I$(5).IXA_INCHIBUILDER_Destroy$O$O(logger, builder);
}
}, 1);

Clazz.newMeth(C$, 'getStatus$O',  function (logger) {
return ($I$(5).IXA_STATUS_HasError$O(logger) ? $I$(14).ERROR : $I$(5).IXA_STATUS_HasWarning$O(logger) ? $I$(14).WARNING : $I$(14).SUCCESS);
}, 1);

Clazz.newMeth(C$, 'getMessages$O',  function (logger) {
var sb=Clazz.new_($I$(15,1));
var messageCount=$I$(5).IXA_STATUS_GetCount$O(logger);
for (var i=0; i < messageCount; i++) {
if (i > 0) {
sb.append$S("; ");
}sb.append$S($I$(5).IXA_STATUS_GetMessage$O$I(logger, i));
}
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'molToInchi$S',  function (molText) {
return C$.molToInchi$S$io_github_dan2097_jnainchi_InchiOptions(molText, $I$(4).DEFAULT_OPTIONS);
}, 1);

Clazz.newMeth(C$, 'molToInchi$S$io_github_dan2097_jnainchi_InchiOptions',  function (molText, options) {
C$.checkLibrary$();
var hStatus=$I$(5).IXA_STATUS_Create$();
var nativeMol=$I$(5).IXA_MOL_Create$O(hStatus);
if ($I$(5).IXA_STATUS_HasError$O(hStatus)) {
return Clazz.new_(["", "", C$.getMessages$O(hStatus), "", $I$(14).ERROR],$I$(13,1).c$$S$S$S$S$io_github_dan2097_jnainchi_InchiStatus);
}return C$.buildInchi$O$O$io_github_dan2097_jnainchi_InchiOptions(hStatus, nativeMol, options);
}, 1);

Clazz.newMeth(C$, 'inchiToInchi$S$io_github_dan2097_jnainchi_InchiOptions',  function (inchi, options) {
C$.checkLibrary$();
var logger=$I$(5).IXA_STATUS_Create$();
var nativeMol=$I$(5).IXA_MOL_Create$O(logger);
try {
$I$(5).IXA_MOL_ReadInChI$O$O$S(logger, nativeMol, inchi);
return C$.buildInchi$O$O$io_github_dan2097_jnainchi_InchiOptions(logger, nativeMol, options);
} finally {
$I$(5).IXA_MOL_Destroy$O$O(logger, nativeMol);
}
}, 1);

Clazz.newMeth(C$, 'inchiToInchiKey$S',  function (inchi) {
C$.checkLibrary$();
var logger=$I$(5).IXA_STATUS_Create$();
var hBuilder=$I$(5).IXA_INCHIKEYBUILDER_Create$O(logger);
try {
$I$(5).IXA_INCHIKEYBUILDER_SetInChI$O$O$S(logger, hBuilder, inchi);
var key=$I$(5).IXA_INCHIKEYBUILDER_GetInChIKey$O$O(logger, hBuilder);
var ret=(key == null  ? 20 : 0);
return Clazz.new_([key, $I$(17).of$I(0), "", ""],$I$(16,1).c$$S$io_github_dan2097_jnainchi_InchiKeyStatus$S$S);
} finally {
$I$(5).IXA_STATUS_Destroy$O(logger);
$I$(5).IXA_INCHIBUILDER_Destroy$O$O(null, hBuilder);
}
}, 1);

Clazz.newMeth(C$, 'checkInchi$S$Z',  function (inchi, strict) {
var out=C$.inchiToInchiKey$S(inchi);
return (out == null  ? $I$(18).FAIL_I2I : inchi.charAt$I(inchi.indexOf$S("/") - 1) == "S" ? $I$(18).VALID_STANDARD : $I$(18).VALID_NON_STANDARD);
}, 1);

Clazz.newMeth(C$, 'checkInchiKey$S',  function (inchiKey) {
var szINCHIKey=inchiKey.toCharArray$();
var slen=szINCHIKey.length;
if (slen != 27) {
return $I$(19).INVALID_LENGTH;
}if (szINCHIKey[14] != "-") {
return $I$(19).INVALID_LAYOUT;
}if (szINCHIKey[25] != "-") {
return $I$(19).INVALID_LAYOUT;
}for (var j=0; j < 14; j++) {
if (!C$.isbase26$C(szINCHIKey[j])) {
return $I$(19).INVALID_LAYOUT;
}}
for (var j=15; j < 25; j++) {
if (!C$.isbase26$C(szINCHIKey[j])) {
return $I$(19).INVALID_LAYOUT;
}}
if (!C$.isbase26$C(szINCHIKey[26])) {
return $I$(19).INVALID_LAYOUT;
}for (var j=0; j < 10; j+=3) {
if (szINCHIKey[j] == "E") {
return $I$(19).INVALID_LAYOUT;
}}
for (var j=15; j < 19; j+=3) {
if (szINCHIKey[j] == "E") {
return $I$(19).INVALID_LAYOUT;
}}
if (szINCHIKey[24] != "A") {
return $I$(19).INVALID_VERSION;
}if (szINCHIKey[23] == "S") {
return $I$(19).VALID_STANDARD;
} else if (szINCHIKey[23] == "N") {
return $I$(19).VALID_NON_STANDARD;
} else {
return $I$(19).INVALID_LAYOUT;
}}, 1);

Clazz.newMeth(C$, 'isbase26$C',  function (c) {
return (c >= "A" && c <= "Z" );
}, 1);

Clazz.newMeth(C$, 'getInchiInputFromAuxInfo$S$Z$Z',  function (auxInfo, doNotAddH, diffUnkUndfStereo) {
var inchiInput=Clazz.new_($I$(20,1));
var status=$I$(14).ERROR;
var message="No IXA interface for INCHI from auxinfo";
var chiralFlag=null;
return Clazz.new_($I$(21,1).c$$io_github_dan2097_jnainchi_InchiInput$Boolean$S$io_github_dan2097_jnainchi_InchiStatus,[inchiInput, chiralFlag, message, status]);
}, 1);

Clazz.newMeth(C$, 'getInchiInputFromInchi$S',  function (inchi) {
return C$.getInchiInputFromInchi$S$io_github_dan2097_jnainchi_InchiOptions(inchi, $I$(4).DEFAULT_OPTIONS);
}, 1);

Clazz.newMeth(C$, 'getInchiInputFromInchi$S$io_github_dan2097_jnainchi_InchiOptions',  function (inchi, options) {
C$.checkLibrary$();
var logger=$I$(5).IXA_STATUS_Create$();
var nativeMol=$I$(5).IXA_MOL_Create$O(logger);
try {
$I$(5).IXA_MOL_ReadInChI$O$O$S(logger, nativeMol, inchi);
var inchiInput=Clazz.new_($I$(20,1));
var mapNativeToJavaAtom=Clazz.new_($I$(1,1));
C$.nativeToJavaAtoms$io_github_dan2097_jnainchi_InchiInput$O$java_util_Map(inchiInput, nativeMol, mapNativeToJavaAtom);
C$.nativeToJavaBonds$io_github_dan2097_jnainchi_InchiInput$O$java_util_Map(inchiInput, nativeMol, mapNativeToJavaAtom);
C$.nativeToJavaStereos$io_github_dan2097_jnainchi_InchiInput$O$java_util_Map(inchiInput, nativeMol, mapNativeToJavaAtom);
var message=C$.getMessages$O(logger);
var log="";
var warningFlags=Clazz.array(Long.TYPE, [2, 2]);
return Clazz.new_([inchiInput, message, log, C$.getStatus$O(logger), warningFlags],$I$(22,1).c$$io_github_dan2097_jnainchi_InchiInput$S$S$io_github_dan2097_jnainchi_InchiStatus$JAA);
} finally {
$I$(5).IXA_STATUS_Destroy$O(logger);
$I$(5).IXA_MOL_Destroy$O$O(null, nativeMol);
}
}, 1);

Clazz.newMeth(C$, 'nativeToJavaAtoms$io_github_dan2097_jnainchi_InchiInput$O$java_util_Map',  function (inchiInput, hMolecule, mapNativeToJavaAtom) {
var nAtoms=$I$(5).IXA_MOL_GetNumAtoms$O$O(null, hMolecule);
for (var i=0; i < nAtoms; i++) {
var hAtom=$I$(5).IXA_MOL_GetAtomId$O$O$I(null, hMolecule, i);
var elSymbol=$I$(5).IXA_MOL_GetAtomElement$O$O$O(null, hMolecule, hAtom);
var x=$I$(5).IXA_MOL_GetAtomX$O$O$O(null, hMolecule, hAtom);
var y=$I$(5).IXA_MOL_GetAtomY$O$O$O(null, hMolecule, hAtom);
var z=$I$(5).IXA_MOL_GetAtomZ$O$O$O(null, hMolecule, hAtom);
var atom=Clazz.new_($I$(23,1).c$$S$D$D$D,[elSymbol, x, y, z]);
atom.setImplicitHydrogen$I($I$(5).IXA_MOL_GetAtomHydrogens$O$O$O$I(null, hMolecule, hAtom, 0));
atom.setImplicitProtium$I($I$(5).IXA_MOL_GetAtomHydrogens$O$O$O$I(null, hMolecule, hAtom, 1));
atom.setImplicitDeuterium$I($I$(5).IXA_MOL_GetAtomHydrogens$O$O$O$I(null, hMolecule, hAtom, 2));
atom.setImplicitTritium$I($I$(5).IXA_MOL_GetAtomHydrogens$O$O$O$I(null, hMolecule, hAtom, 3));
var isotopicMass=$I$(5).IXA_MOL_GetAtomMass$O$O$O(null, hMolecule, hAtom);
if (isotopicMass >= 9900 && isotopicMass <= 10100 ) {
var baseMass=(C$.aveMass.getOrDefault$O$O(elSymbol, Integer.valueOf$I(0))).$c();
var delta=isotopicMass - 10000;
isotopicMass=baseMass + delta;
}atom.setIsotopicMass$I(isotopicMass);
atom.setRadical$io_github_dan2097_jnainchi_InchiRadical($I$(6,"of$I",[$I$(5).IXA_MOL_GetAtomRadical$O$O$O(null, hMolecule, hAtom)]));
atom.setCharge$I($I$(5).IXA_MOL_GetAtomCharge$O$O$O(null, hMolecule, hAtom));
inchiInput.addAtom$io_github_dan2097_jnainchi_InchiAtom(atom);
mapNativeToJavaAtom.put$O$O(C$.mapKeyFor$O(hAtom), atom);
}
}, 1);

Clazz.newMeth(C$, 'mapKeyFor$O',  function (hAtom) {
var i=(1 ? hAtom :-1);
return (i >= 0 ? Integer.valueOf$I(i) : hAtom);
}, 1);

Clazz.newMeth(C$, 'nativeToJavaBonds$io_github_dan2097_jnainchi_InchiInput$O$java_util_Map',  function (inchiInput, hMolecule, mapNativeToJavaAtom) {
var numBonds=$I$(5).IXA_MOL_GetNumBonds$O$O(null, hMolecule);
for (var i=0; i < numBonds; i++) {
var hBond=$I$(5).IXA_MOL_GetBondId$O$O$I(null, hMolecule, i);
var bondType=$I$(7,"of$I",[$I$(5).IXA_MOL_GetBondType$O$O$O(null, hMolecule, hBond)]);
var a1=$I$(5).IXA_MOL_GetBondAtom1$O$O$O(null, hMolecule, hBond);
var a2=$I$(5).IXA_MOL_GetBondAtom2$O$O$O(null, hMolecule, hBond);
var bondStereo=$I$(8,"of$I",[$I$(5).IXA_MOL_GetBondWedge$O$O$O$O(null, hMolecule, hBond, a1)]);
var atom1=mapNativeToJavaAtom.get$O(C$.mapKeyFor$O(a1));
var atom2=mapNativeToJavaAtom.get$O(C$.mapKeyFor$O(a2));
inchiInput.addBond$io_github_dan2097_jnainchi_InchiBond(Clazz.new_($I$(24,1).c$$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiBondType$io_github_dan2097_jnainchi_InchiBondStereo,[atom1, atom2, bondType, bondStereo]));
}
}, 1);

Clazz.newMeth(C$, 'nativeToJavaStereos$io_github_dan2097_jnainchi_InchiInput$O$java_util_Map',  function (inchiInput, hMolecule, mapNativeToJavaAtom) {
var numStereo=$I$(5).IXA_MOL_GetNumStereos$O$O(null, hMolecule);
for (var is=0; is < numStereo; is++) {
var atoms=Clazz.array($I$(23), [4]);
var stereo=$I$(5).IXA_MOL_GetStereoId$O$O$I(null, hMolecule, is);
for (var i=0; i < 4; i++) {
var vertex=$I$(5).IXA_MOL_GetStereoVertex$O$O$O$I(null, hMolecule, stereo, i);
atoms[i]=mapNativeToJavaAtom.get$O(C$.mapKeyFor$O(vertex));
}
var stereoType;
switch ($I$(5).IXA_MOL_GetStereoTopology$O$O$O(null, hMolecule, stereo)) {
case 2:
stereoType=$I$(9).Tetrahedral;
break;
case 3:
stereoType=$I$(9).DoubleBond;
var centralBond=$I$(5).IXA_MOL_GetStereoCentralBond$O$O$O(null, hMolecule, stereo);
var internal1=$I$(5).IXA_MOL_GetBondAtom1$O$O$O(null, hMolecule, centralBond);
var internal2=$I$(5).IXA_MOL_GetBondAtom2$O$O$O(null, hMolecule, centralBond);
atoms[1]=mapNativeToJavaAtom.get$O(C$.mapKeyFor$O(internal1));
atoms[2]=mapNativeToJavaAtom.get$O(C$.mapKeyFor$O(internal2));
break;
case 4:
stereoType=$I$(9).Allene;
break;
default:
return;
}
var parity=$I$(10,"of$I",[$I$(5).IXA_MOL_GetStereoParity$O$O$O(null, hMolecule, stereo)]);
var ca=$I$(5).IXA_MOL_GetStereoCentralAtom$O$O$O(null, hMolecule, stereo);
var centralAtom=mapNativeToJavaAtom.get$O(C$.mapKeyFor$O(ca));
System.out.println$S("central atom: " + centralAtom);
inchiInput.addStereo$io_github_dan2097_jnainchi_InchiStereo(Clazz.new_($I$(11,1).c$$io_github_dan2097_jnainchi_InchiAtomA$io_github_dan2097_jnainchi_InchiAtom$io_github_dan2097_jnainchi_InchiStereoType$io_github_dan2097_jnainchi_InchiStereoParity,[atoms, centralAtom, stereoType, parity]));
}
}, 1);

Clazz.newMeth(C$, 'toString$BA',  function (cstr) {
var sb=Clazz.new_($I$(15,1).c$$I,[cstr.length]);
for (var i=0; i < cstr.length; i++) {
var ch=String.fromCharCode(cstr[i]);
if (ch == "\u0000") {
break;
}sb.append$C(ch);
}
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'getInchiLibraryVersion$',  function () {
try {
var is=Clazz.getClass($I$(25)).getResourceAsStream$S("jnainchi_build.props");
try {
var props=Clazz.new_($I$(26,1));
props.load$java_io_InputStream(is);
return props.getProperty$S("inchi_version");

}finally{/*res*/is&&is.close$&&is.close$();}
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
return null;
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'getJnaInchiVersion$',  function () {
try {
var is=Clazz.getClass($I$(25)).getResourceAsStream$S("jnainchi_build.props");
try {
var props=Clazz.new_($I$(26,1));
props.load$java_io_InputStream(is);
return props.getProperty$S("jnainchi_version");

}finally{/*res*/is&&is.close$&&is.close$();}
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
return null;
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'checkLibrary$',  function () {
if (C$.libraryLoadingError != null ) {
var platform=(C$.isJS ? "WASM" : $I$(2).RESOURCE_PREFIX);
throw Clazz.new_(Clazz.load('RuntimeException').c$$S$Throwable,["Error loading InChI native code. Please check that the binaries for your platform (" + platform + ") have been included on the classpath." , C$.libraryLoadingError]);
}}, 1);

C$.$static$=function(){C$.$static$=0;
C$.isJS=(true ||false);
C$.libraryLoadingError=null;
C$.aveMass=Clazz.new_($I$(1,1));
{
try {
var s=$I$(2).RESOURCE_PREFIX;
$I$(3).JNA_NATIVE_LIB.getName$();
} catch (e) {
e.printStackTrace$();
C$.libraryLoadingError=e;
}
C$.aveMass.put$O$O("H", Integer.valueOf$I(1));
C$.aveMass.put$O$O("D", Integer.valueOf$I(2));
C$.aveMass.put$O$O("T", Integer.valueOf$I(3));
C$.aveMass.put$O$O("He", Integer.valueOf$I(4));
C$.aveMass.put$O$O("Li", Integer.valueOf$I(7));
C$.aveMass.put$O$O("Be", Integer.valueOf$I(9));
C$.aveMass.put$O$O("B", Integer.valueOf$I(11));
C$.aveMass.put$O$O("C", Integer.valueOf$I(12));
C$.aveMass.put$O$O("N", Integer.valueOf$I(14));
C$.aveMass.put$O$O("O", Integer.valueOf$I(16));
C$.aveMass.put$O$O("F", Integer.valueOf$I(19));
C$.aveMass.put$O$O("Ne", Integer.valueOf$I(20));
C$.aveMass.put$O$O("Na", Integer.valueOf$I(23));
C$.aveMass.put$O$O("Mg", Integer.valueOf$I(24));
C$.aveMass.put$O$O("Al", Integer.valueOf$I(27));
C$.aveMass.put$O$O("Si", Integer.valueOf$I(28));
C$.aveMass.put$O$O("P", Integer.valueOf$I(31));
C$.aveMass.put$O$O("S", Integer.valueOf$I(32));
C$.aveMass.put$O$O("Cl", Integer.valueOf$I(35));
C$.aveMass.put$O$O("Ar", Integer.valueOf$I(40));
C$.aveMass.put$O$O("K", Integer.valueOf$I(39));
C$.aveMass.put$O$O("Ca", Integer.valueOf$I(40));
C$.aveMass.put$O$O("Sc", Integer.valueOf$I(45));
C$.aveMass.put$O$O("Ti", Integer.valueOf$I(48));
C$.aveMass.put$O$O("V", Integer.valueOf$I(51));
C$.aveMass.put$O$O("Cr", Integer.valueOf$I(52));
C$.aveMass.put$O$O("Mn", Integer.valueOf$I(55));
C$.aveMass.put$O$O("Fe", Integer.valueOf$I(56));
C$.aveMass.put$O$O("Co", Integer.valueOf$I(59));
C$.aveMass.put$O$O("Ni", Integer.valueOf$I(59));
C$.aveMass.put$O$O("Cu", Integer.valueOf$I(64));
C$.aveMass.put$O$O("Zn", Integer.valueOf$I(65));
C$.aveMass.put$O$O("Ga", Integer.valueOf$I(70));
C$.aveMass.put$O$O("Ge", Integer.valueOf$I(73));
C$.aveMass.put$O$O("As", Integer.valueOf$I(75));
C$.aveMass.put$O$O("Se", Integer.valueOf$I(79));
C$.aveMass.put$O$O("Br", Integer.valueOf$I(80));
C$.aveMass.put$O$O("Kr", Integer.valueOf$I(84));
C$.aveMass.put$O$O("Rb", Integer.valueOf$I(85));
C$.aveMass.put$O$O("Sr", Integer.valueOf$I(88));
C$.aveMass.put$O$O("Y", Integer.valueOf$I(89));
C$.aveMass.put$O$O("Zr", Integer.valueOf$I(91));
C$.aveMass.put$O$O("Nb", Integer.valueOf$I(93));
C$.aveMass.put$O$O("Mo", Integer.valueOf$I(96));
C$.aveMass.put$O$O("Tc", Integer.valueOf$I(98));
C$.aveMass.put$O$O("Ru", Integer.valueOf$I(101));
C$.aveMass.put$O$O("Rh", Integer.valueOf$I(103));
C$.aveMass.put$O$O("Pd", Integer.valueOf$I(106));
C$.aveMass.put$O$O("Ag", Integer.valueOf$I(108));
C$.aveMass.put$O$O("Cd", Integer.valueOf$I(112));
C$.aveMass.put$O$O("In", Integer.valueOf$I(115));
C$.aveMass.put$O$O("Sn", Integer.valueOf$I(119));
C$.aveMass.put$O$O("Sb", Integer.valueOf$I(122));
C$.aveMass.put$O$O("Te", Integer.valueOf$I(128));
C$.aveMass.put$O$O("I", Integer.valueOf$I(127));
C$.aveMass.put$O$O("Xe", Integer.valueOf$I(131));
C$.aveMass.put$O$O("Cs", Integer.valueOf$I(133));
C$.aveMass.put$O$O("Ba", Integer.valueOf$I(137));
C$.aveMass.put$O$O("La", Integer.valueOf$I(139));
C$.aveMass.put$O$O("Ce", Integer.valueOf$I(140));
C$.aveMass.put$O$O("Pr", Integer.valueOf$I(141));
C$.aveMass.put$O$O("Nd", Integer.valueOf$I(144));
C$.aveMass.put$O$O("Pm", Integer.valueOf$I(145));
C$.aveMass.put$O$O("Sm", Integer.valueOf$I(150));
C$.aveMass.put$O$O("Eu", Integer.valueOf$I(152));
C$.aveMass.put$O$O("Gd", Integer.valueOf$I(157));
C$.aveMass.put$O$O("Tb", Integer.valueOf$I(159));
C$.aveMass.put$O$O("Dy", Integer.valueOf$I(163));
C$.aveMass.put$O$O("Ho", Integer.valueOf$I(165));
C$.aveMass.put$O$O("Er", Integer.valueOf$I(167));
C$.aveMass.put$O$O("Tm", Integer.valueOf$I(169));
C$.aveMass.put$O$O("Yb", Integer.valueOf$I(173));
C$.aveMass.put$O$O("Lu", Integer.valueOf$I(175));
C$.aveMass.put$O$O("Hf", Integer.valueOf$I(178));
C$.aveMass.put$O$O("Ta", Integer.valueOf$I(181));
C$.aveMass.put$O$O("W", Integer.valueOf$I(184));
C$.aveMass.put$O$O("Re", Integer.valueOf$I(186));
C$.aveMass.put$O$O("Os", Integer.valueOf$I(190));
C$.aveMass.put$O$O("Ir", Integer.valueOf$I(192));
C$.aveMass.put$O$O("Pt", Integer.valueOf$I(195));
C$.aveMass.put$O$O("Au", Integer.valueOf$I(197));
C$.aveMass.put$O$O("Hg", Integer.valueOf$I(201));
C$.aveMass.put$O$O("Tl", Integer.valueOf$I(204));
C$.aveMass.put$O$O("Pb", Integer.valueOf$I(207));
C$.aveMass.put$O$O("Bi", Integer.valueOf$I(209));
C$.aveMass.put$O$O("Po", Integer.valueOf$I(209));
C$.aveMass.put$O$O("At", Integer.valueOf$I(210));
C$.aveMass.put$O$O("Rn", Integer.valueOf$I(222));
C$.aveMass.put$O$O("Fr", Integer.valueOf$I(223));
C$.aveMass.put$O$O("Ra", Integer.valueOf$I(226));
C$.aveMass.put$O$O("Ac", Integer.valueOf$I(227));
C$.aveMass.put$O$O("Th", Integer.valueOf$I(232));
C$.aveMass.put$O$O("Pa", Integer.valueOf$I(231));
C$.aveMass.put$O$O("U", Integer.valueOf$I(238));
C$.aveMass.put$O$O("Np", Integer.valueOf$I(237));
C$.aveMass.put$O$O("Pu", Integer.valueOf$I(244));
C$.aveMass.put$O$O("Am", Integer.valueOf$I(243));
C$.aveMass.put$O$O("Cm", Integer.valueOf$I(247));
C$.aveMass.put$O$O("Bk", Integer.valueOf$I(247));
C$.aveMass.put$O$O("Cf", Integer.valueOf$I(251));
C$.aveMass.put$O$O("Es", Integer.valueOf$I(252));
C$.aveMass.put$O$O("Fm", Integer.valueOf$I(257));
C$.aveMass.put$O$O("Md", Integer.valueOf$I(258));
C$.aveMass.put$O$O("No", Integer.valueOf$I(259));
C$.aveMass.put$O$O("Lr", Integer.valueOf$I(260));
C$.aveMass.put$O$O("Rf", Integer.valueOf$I(261));
C$.aveMass.put$O$O("Db", Integer.valueOf$I(270));
C$.aveMass.put$O$O("Sg", Integer.valueOf$I(269));
C$.aveMass.put$O$O("Bh", Integer.valueOf$I(270));
C$.aveMass.put$O$O("Hs", Integer.valueOf$I(270));
C$.aveMass.put$O$O("Mt", Integer.valueOf$I(278));
C$.aveMass.put$O$O("Ds", Integer.valueOf$I(281));
C$.aveMass.put$O$O("Rg", Integer.valueOf$I(281));
C$.aveMass.put$O$O("Cn", Integer.valueOf$I(285));
C$.aveMass.put$O$O("Nh", Integer.valueOf$I(278));
C$.aveMass.put$O$O("Fl", Integer.valueOf$I(289));
C$.aveMass.put$O$O("Mc", Integer.valueOf$I(289));
C$.aveMass.put$O$O("Lv", Integer.valueOf$I(293));
C$.aveMass.put$O$O("Ts", Integer.valueOf$I(297));
C$.aveMass.put$O$O("Og", Integer.valueOf$I(294));
};
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v5');//Created 2025-03-05 15:13:28 Java2ScriptVisitor version 5.0.1-v5 net.sf.j2s.core.jar version 5.0.1-v5
