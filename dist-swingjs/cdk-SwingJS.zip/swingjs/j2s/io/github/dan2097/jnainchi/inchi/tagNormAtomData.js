(function(){var P$=Clazz.newPackage("io.github.dan2097.jnainchi.inchi"),I$=[[0,'java.util.Arrays']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "tagNormAtomData", null, 'com.sun.jna.Structure', [['com.sun.jna.Structure','com.sun.jna.Structure.ByReference']]);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.nNumRemovedProtonsIsotopic=Clazz.array(Short.TYPE, [3]);
this.num_iso_H=Clazz.array(Short.TYPE, [3]);
},1);

C$.$fields$=[['I',['num_at','num_removed_H','num_bonds','num_isotopic','bExists','bDeleted','bHasIsotopicLayer','bTautomeric','bTautPreprocessed','nNumRemovedProtons'],'O',['at','io.github.dan2097.jnainchi.inchi.tagNormAtom','+at_fixed_bonds','nNumRemovedProtonsIsotopic','short[]','+num_iso_H','bTautFlags','com.sun.jna.NativeLong','+bTautFlagsDone','+bNormalizationFlags']]]

Clazz.newMeth(C$, 'getFieldOrder$',  function () {
return $I$(1,"asList$OA",[Clazz.array(String, -1, ["at", "at_fixed_bonds", "num_at", "num_removed_H", "num_bonds", "num_isotopic", "bExists", "bDeleted", "bHasIsotopicLayer", "bTautomeric", "bTautPreprocessed", "nNumRemovedProtons", "nNumRemovedProtonsIsotopic", "num_iso_H", "bTautFlags", "bTautFlagsDone", "bNormalizationFlags"])]);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v5');//Created 2025-02-24 22:11:33 Java2ScriptVisitor version 5.0.1-v5 net.sf.j2s.core.jar version 5.0.1-v5
