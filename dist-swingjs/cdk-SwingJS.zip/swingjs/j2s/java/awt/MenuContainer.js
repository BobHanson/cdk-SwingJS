(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "MenuContainer");
})();
;Clazz.setTVer('5.0.1-v5');//Created 2025-02-23 19:45:21 Java2ScriptVisitor version 5.0.1-v5 net.sf.j2s.core.jar version 5.0.1-v5
